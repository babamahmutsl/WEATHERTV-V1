package com.example.havatv

import android.annotation.SuppressLint
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import org.json.JSONObject

private const val RADAR_HTML = """<!DOCTYPE html>
<html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"/>
<style>
html,body,#map{height:100%;margin:0;background:#0b1320}
#info{position:absolute;left:12px;bottom:26px;z-index:1000;background:rgba(0,0,0,.65);color:#fff;
font:600 22px sans-serif;padding:6px 14px;border-radius:8px}
</style></head><body>
<div id="map"></div><div id="info">Radar yükleniyor…</div>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
var CFG = %%CFG%%;
var map = L.map('map', {zoomControl:false, keyboard:false}).setView([CFG.lat, CFG.lon], CFG.zoom);
var baseUrl = CFG.base == 'light'
  ? 'https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png'
  : 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png';
L.tileLayer(baseUrl, {subdomains:'abcd', maxZoom:19, attribution:'© OpenStreetMap © CARTO'}).addTo(map);
L.circleMarker([CFG.lat, CFG.lon], {radius:7, color:'#ffffff', weight:3, fillColor:'#ff5252', fillOpacity:1}).addTo(map);

var frames = [], layers = [], pastCount = 0, idx = 0, timer = null, host = '';
var info = document.getElementById('info');
function pad(n){ return n < 10 ? '0' + n : '' + n; }

function show(i){
  if (!layers.length) return;
  idx = (i + layers.length) % layers.length;
  for (var k = 0; k < layers.length; k++) { layers[k].setOpacity(k == idx ? CFG.opacity / 100 : 0); }
  var dt = new Date(frames[idx].time * 1000);
  info.textContent = (idx >= pastCount ? 'Tahmin · ' : 'Radar · ') + pad(dt.getHours()) + ':' + pad(dt.getMinutes());
}
function step(d){ show(idx + d); }
function play(){ if (timer) return; timer = setInterval(function(){ step(1); }, CFG.speed); }
function pause(){ if (timer) { clearInterval(timer); timer = null; } }
function togglePlay(){ if (timer) pause(); else play(); }
function pan(dx, dy){ map.panBy([dx * 160, dy * 160]); }
function zoomBy(d){ map.setZoom(map.getZoom() + d); }
function home(){ map.setView([CFG.lat, CFG.lon], CFG.zoom); }

fetch('https://api.rainviewer.com/public/weather-maps.json')
  .then(function(r){ return r.json(); })
  .then(function(d){
    host = d.host;
    var past = (d.radar && d.radar.past) ? d.radar.past : [];
    var now = (d.radar && d.radar.nowcast) ? d.radar.nowcast : [];
    pastCount = past.length;
    frames = past.concat(now);
    if (!frames.length) { info.textContent = 'Radar verisi yok'; return; }
    for (var i = 0; i < frames.length; i++) {
      var url = host + frames[i].path + '/256/{z}/{x}/{y}/' + CFG.color + '/' + CFG.smooth + '_' + CFG.snow + '.png';
      var lyr = L.tileLayer(url, {opacity:0, maxNativeZoom:7, maxZoom:12, zIndex:10 + i});
      lyr.addTo(map);
      layers.push(lyr);
    }
    show(pastCount > 0 ? pastCount - 1 : 0);
    play();
  })
  .catch(function(e){ info.textContent = 'Radar verisi alınamadı'; });
</script></body></html>"""

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun RadarScreen(s: Settings, city: City) {
    val holder = remember { arrayOfNulls<WebView>(1) }

    val cfgKey = listOf(
        s.str("radarBase"), s.int("radarColor"), s.int("radarOpacity"), s.int("radarSpeed"),
        s.int("radarZoom"), s.bool("radarSmooth"), s.bool("radarSnow"), city.lat, city.lon,
    )

    fun js(code: String) {
        holder[0]?.evaluateJavascript(code, null)
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Box(modifier = Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(16.dp))) {
            key(cfgKey) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx ->
                        val cfg = JSONObject()
                            .put("lat", city.lat)
                            .put("lon", city.lon)
                            .put("zoom", s.int("radarZoom"))
                            .put("base", s.str("radarBase"))
                            .put("color", s.int("radarColor"))
                            .put("opacity", s.int("radarOpacity"))
                            .put("speed", s.int("radarSpeed"))
                            .put("smooth", if (s.bool("radarSmooth")) 1 else 0)
                            .put("snow", if (s.bool("radarSnow")) 1 else 0)
                        val html = RADAR_HTML.replace("%%CFG%%", cfg.toString())
                        WebView(ctx).apply {
                            layoutParams = ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT,
                            )
                            this.settings.javaScriptEnabled = true
                            this.settings.domStorageEnabled = true
                            isFocusable = false
                            isFocusableInTouchMode = false
                            setBackgroundColor(0xFF0B1320.toInt())
                            webViewClient = WebViewClient()
                            loadDataWithBaseURL("https://havatv.local/", html, "text/html", "utf-8", null)
                            holder[0] = this
                        }
                    },
                    onRelease = { it.destroy() },
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            TvButton(text = "⏯ Oynat/Durdur", onClick = { js("togglePlay()") }, autoFocus = true, fontSize = 18.sp)
            TvButton(text = "⏮", onClick = { js("pause();step(-1)") }, fontSize = 18.sp)
            TvButton(text = "⏭", onClick = { js("pause();step(1)") }, fontSize = 18.sp)
            TvButton(text = "◀", onClick = { js("pan(-1,0)") }, fontSize = 18.sp)
            TvButton(text = "▲", onClick = { js("pan(0,-1)") }, fontSize = 18.sp)
            TvButton(text = "▼", onClick = { js("pan(0,1)") }, fontSize = 18.sp)
            TvButton(text = "▶", onClick = { js("pan(1,0)") }, fontSize = 18.sp)
            TvButton(text = "＋", onClick = { js("zoomBy(1)") }, fontSize = 18.sp)
            TvButton(text = "－", onClick = { js("zoomBy(-1)") }, fontSize = 18.sp)
            TvButton(text = "📍", onClick = { js("home()") }, fontSize = 18.sp)
        }
    }
}
