package com.example.havatv

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

// ---------------------------------------------------------------- modeller

data class City(val name: String, val lat: Double, val lon: Double)

data class Current(
    val temp: Double,
    val feels: Double,
    val humidity: Int,
    val windKmh: Double,
    val windDir: Int,
    val gustKmh: Double,
    val pressure: Double?,
    val cloud: Int,
    val precip: Double,
    val code: Int,
    val isDay: Boolean,
)

data class HourItem(
    val time: String,
    val epochH: Long,
    val temp: Double,
    val code: Int,
    val isDay: Boolean,
    val rainProb: Int?,
    val precip: Double,
    val gust: Double,
    val uv: Double,
    val pressure: Double?,
)

data class DayItem(
    val label: String,
    val date: String,
    val min: Double,
    val max: Double,
    val code: Int,
    val sunrise: String,
    val sunset: String,
    val uvMax: Double,
    val rainSum: Double,
    val rainProbMax: Int?,
    val gustMax: Double,
)

/** Ortalamaya giren bir kaynağın anlık sıcaklığı ve ağırlığı. */
data class SrcTemp(val name: String, val temp: Double, val weight: Double)

data class Weather(
    val current: Current,
    val nowTime: String, // 2026-10-29T09:15 (yerel)
    val hours: List<HourItem>,
    val days: List<DayItem>,
    val updated: String,
    val uvNow: Double,
    val sources: List<SrcTemp>,
    val pressureTrend: Double?, // önümüzdeki 3 saatte hPa değişimi
)

data class Aqi(val european: Int, val pm25: Double, val pm10: Double)

data class KpPoint(val timeMs: Long, val kp: Double, val observed: Boolean)

data class Quake(
    val id: String,
    val timeMs: Long,
    val mag: Double,
    val place: String,
    val lat: Double,
    val lon: Double,
    val depthKm: Double,
    val distKm: Double,
)

object Cities {
    val all = listOf(
        City("Yenimahalle (Ankara)", 39.9667, 32.8000),
        City("Ankara", 39.9334, 32.8597),
        City("İstanbul", 41.0082, 28.9784),
        City("İzmir", 38.4237, 27.1428),
        City("Bursa", 40.1885, 29.0610),
        City("Antalya", 36.8969, 30.7133),
        City("Adana", 37.0000, 35.3213),
        City("Konya", 37.8746, 32.4932),
        City("Gaziantep", 37.0662, 37.3833),
        City("Kayseri", 38.7312, 35.4787),
        City("Mersin", 36.8121, 34.6415),
        City("Eskişehir", 39.7767, 30.5206),
        City("Diyarbakır", 37.9144, 40.2306),
        City("Samsun", 41.2867, 36.3300),
        City("Trabzon", 41.0027, 39.7168),
        City("Erzurum", 39.9055, 41.2658),
        City("Van", 38.4891, 43.4089),
        City("Denizli", 37.7765, 29.0864),
        City("Malatya", 38.3552, 38.3095),
        City("Sakarya (Adapazarı)", 40.7569, 30.3781),
        City("Kocaeli (İzmit)", 40.7654, 29.9408),
        City("Balıkesir", 39.6484, 27.8826),
        City("Tekirdağ", 40.9833, 27.5167),
        City("Edirne", 41.6771, 26.5557),
        City("Çanakkale", 40.1553, 26.4142),
        City("Muğla", 37.2153, 28.3636),
        City("Aydın", 37.8560, 27.8416),
        City("Manisa", 38.6191, 27.4289),
        City("Hatay (Antakya)", 36.2025, 36.1606),
        City("Şanlıurfa", 37.1591, 38.7969),
        City("Sivas", 39.7477, 37.0179),
        City("Zonguldak", 41.4564, 31.7987),
        City("Kastamonu", 41.3887, 33.7827),
        City("Ordu", 40.9839, 37.8764),
        City("Rize", 41.0201, 40.5234),
        City("Çorum", 40.5506, 34.9556),
    )
}

// ---------------------------------------------------------------- yardımcılar

fun httpGet(url: String, timeoutMs: Int = 12_000): String {
    val conn = URL(url).openConnection() as HttpURLConnection
    conn.connectTimeout = timeoutMs
    conn.readTimeout = timeoutMs
    conn.setRequestProperty("User-Agent", "HavaTV/0.2 (Android TV hava durumu uygulamasi)")
    conn.setRequestProperty("Accept", "application/json")
    try {
        val code = conn.responseCode
        if (code == 204) return ""
        if (code != 200) throw RuntimeException("Sunucu hatası: $code")
        return conn.inputStream.bufferedReader().use { it.readText() }
    } finally {
        conn.disconnect()
    }
}

fun haversineKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
    val r = 6371.0
    val dLat = Math.toRadians(lat2 - lat1)
    val dLon = Math.toRadians(lon2 - lon1)
    val a = sin(dLat / 2).pow(2) + cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(dLon / 2).pow(2)
    return 2 * r * asin(sqrt(a))
}

private fun JSONObject.optDoubleOrNull(k: String): Double? =
    if (has(k) && !isNull(k)) optDouble(k) else null

/** (değer, ağırlık) çiftlerinin ağırlıklı ortalaması. Ağırlığı 0 olanlar sayılmaz. */
private fun wavg(items: List<Pair<Double, Double>>): Double? {
    var sw = 0.0
    var sv = 0.0
    for ((v, w) in items) {
        if (w > 0.0) {
            sw += w
            sv += v * w
        }
    }
    return if (sw > 0.0) sv / sw else null
}

private fun MutableList<Pair<Double, Double>>.addIf(v: Double?, w: Double) {
    if (v != null && w > 0.0) add(v to w)
}

private fun relHumidity(t: Double, td: Double): Double {
    val a = 17.625
    val b = 243.04
    return (100.0 * exp(a * td / (b + td)) / exp(a * t / (b + t))).coerceIn(0.0, 100.0)
}

private fun dateOf(epochH: Long, offsetSec: Int): String =
    LocalDateTime.ofEpochSecond(epochH * 3600L + offsetSec, 0, ZoneOffset.UTC).toLocalDate().toString()

/**
 * Kaynaklar yağış konusunda ayrışırsa ortalama yağışa göre simgeyi düzeltir.
 * Kar ve gök gürültüsü gibi özel durumlara dokunmaz.
 */
private fun adjustCode(code: Int, precip: Double, cloud: Int, twoSources: Boolean, addAt: Double): Int {
    val precipCode = code in 51..67 || code in 80..82
    val special = code in 71..77 || code in 85..99
    if (special) return code
    if (!precipCode && precip >= addAt) return if (precip >= 2.5) 63 else 61
    if (precipCode && twoSources && precip < 0.05) return if (cloud >= 60) 3 else 2
    return code
}

// ---------------------------------------------------------------- kaynaklar

private class Om(val w: Weather, val offsetSec: Int)

private class MetPoint(
    val epochH: Long,
    val temp: Double?,
    val pressure: Double?,
    val humidity: Double?,
    val windMs: Double?,
    val cloud: Double?,
    val precip: Double?,
)

private class MetarObs(
    val station: String,
    val distKm: Double,
    val temp: Double?,
    val dew: Double?,
    val windKmh: Double?,
    val pressure: Double?,
)

object WeatherApi {

    /** Üç kaynağı (Open-Meteo, met.no, METAR) ağırlıklı ortalamayla birleştirir. */
    fun fetch(city: City, s: Settings): Weather {
        val om = fetchOpenMeteo(city)
        val wo = s.int("wOm") / 100.0
        val wm = s.int("wMet") / 100.0
        val wr = s.int("wMetar") / 100.0
        val met = if (wm > 0.0) runCatching { fetchMetNo(city) }.getOrNull() else null
        val metar = if (wr > 0.0) runCatching { fetchMetar(city) }.getOrNull() else null
        return blend(om, met, metar, wo, wm, wr)
    }

    private fun fetchOpenMeteo(city: City): Om {
        val url = "https://api.open-meteo.com/v1/forecast" +
            "?latitude=${city.lat}&longitude=${city.lon}" +
            "&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,weather_code," +
            "pressure_msl,wind_speed_10m,wind_direction_10m,wind_gusts_10m,cloud_cover,precipitation" +
            "&hourly=temperature_2m,weather_code,precipitation_probability,precipitation,is_day," +
            "wind_gusts_10m,uv_index,pressure_msl" +
            "&daily=weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset,uv_index_max," +
            "precipitation_sum,precipitation_probability_max,wind_gusts_10m_max" +
            "&timezone=auto&forecast_days=10&wind_speed_unit=kmh"

        val root = JSONObject(httpGet(url))
        val offset = root.optInt("utc_offset_seconds", 0)

        val cur = root.getJSONObject("current")
        val current = Current(
            temp = cur.getDouble("temperature_2m"),
            feels = cur.getDouble("apparent_temperature"),
            humidity = cur.getInt("relative_humidity_2m"),
            windKmh = cur.getDouble("wind_speed_10m"),
            windDir = cur.optInt("wind_direction_10m", 0),
            gustKmh = cur.optDouble("wind_gusts_10m", 0.0),
            pressure = cur.optDoubleOrNull("pressure_msl"),
            cloud = cur.optInt("cloud_cover", 0),
            precip = cur.optDouble("precipitation", 0.0),
            code = cur.getInt("weather_code"),
            isDay = cur.getInt("is_day") == 1,
        )
        val curTime = cur.getString("time") // 2026-10-29T09:00

        val hourly = root.getJSONObject("hourly")
        val times = hourly.getJSONArray("time")
        val temps = hourly.getJSONArray("temperature_2m")
        val codes = hourly.getJSONArray("weather_code")
        val probs = hourly.getJSONArray("precipitation_probability")
        val precips = hourly.getJSONArray("precipitation")
        val isDays = hourly.getJSONArray("is_day")
        val gusts = hourly.getJSONArray("wind_gusts_10m")
        val uvs = hourly.getJSONArray("uv_index")
        val press = hourly.getJSONArray("pressure_msl")

        val startKey = curTime.substring(0, 13)
        var start = 0
        for (i in 0 until times.length()) {
            if (times.getString(i).substring(0, 13) >= startKey) {
                start = i
                break
            }
        }
        val zone = ZoneOffset.ofTotalSeconds(offset)
        val hours = ArrayList<HourItem>()
        var i = start
        while (i < times.length() && hours.size < 72) {
            val t = times.getString(i)
            hours.add(
                HourItem(
                    time = t,
                    epochH = LocalDateTime.parse(t).toEpochSecond(zone) / 3600L,
                    temp = temps.optDouble(i, 0.0),
                    code = codes.optInt(i, 0),
                    isDay = isDays.optInt(i, 1) == 1,
                    rainProb = if (probs.isNull(i)) null else probs.getInt(i),
                    precip = precips.optDouble(i, 0.0),
                    gust = gusts.optDouble(i, 0.0),
                    uv = uvs.optDouble(i, 0.0),
                    pressure = if (press.isNull(i)) null else press.optDouble(i),
                )
            )
            i++
        }

        val daily = root.getJSONObject("daily")
        val dTimes = daily.getJSONArray("time")
        val dMax = daily.getJSONArray("temperature_2m_max")
        val dMin = daily.getJSONArray("temperature_2m_min")
        val dCode = daily.getJSONArray("weather_code")
        val dSunrise = daily.getJSONArray("sunrise")
        val dSunset = daily.getJSONArray("sunset")
        val dUv = daily.getJSONArray("uv_index_max")
        val dRain = daily.getJSONArray("precipitation_sum")
        val dProb = daily.getJSONArray("precipitation_probability_max")
        val dGust = daily.getJSONArray("wind_gusts_10m_max")
        val days = ArrayList<DayItem>()
        for (d in 0 until minOf(10, dTimes.length())) {
            val date = dTimes.getString(d)
            val label = when (d) {
                0 -> "Bugün"
                1 -> "Yarın"
                else -> dayName(LocalDate.parse(date))
            }
            days.add(
                DayItem(
                    label = label,
                    date = date,
                    min = dMin.optDouble(d, 0.0),
                    max = dMax.optDouble(d, 0.0),
                    code = dCode.optInt(d, 0),
                    sunrise = dSunrise.getString(d),
                    sunset = dSunset.getString(d),
                    uvMax = dUv.optDouble(d, 0.0),
                    rainSum = dRain.optDouble(d, 0.0),
                    rainProbMax = if (dProb.isNull(d)) null else dProb.getInt(d),
                    gustMax = dGust.optDouble(d, 0.0),
                )
            )
        }

        val w = Weather(
            current = current,
            nowTime = curTime,
            hours = hours,
            days = days,
            updated = curTime.substring(11, 16),
            uvNow = hours.firstOrNull()?.uv ?: 0.0,
            sources = listOf(SrcTemp("Open-Meteo", current.temp, 1.0)),
            pressureTrend = null,
        )
        return Om(w, offset)
    }

    private fun fetchMetNo(city: City): List<MetPoint> {
        val lat = String.format(Locale.US, "%.4f", city.lat)
        val lon = String.format(Locale.US, "%.4f", city.lon)
        val root = JSONObject(httpGet("https://api.met.no/weatherapi/locationforecast/2.0/compact?lat=$lat&lon=$lon"))
        val ts = root.getJSONObject("properties").getJSONArray("timeseries")
        val out = ArrayList<MetPoint>()
        for (i in 0 until ts.length()) {
            val e = ts.getJSONObject(i)
            val data = e.getJSONObject("data")
            val d = data.getJSONObject("instant").getJSONObject("details")
            val p1 = data.optJSONObject("next_1_hours")?.optJSONObject("details")
            out.add(
                MetPoint(
                    epochH = Instant.parse(e.getString("time")).toEpochMilli() / 3_600_000L,
                    temp = d.optDoubleOrNull("air_temperature"),
                    pressure = d.optDoubleOrNull("air_pressure_at_sea_level"),
                    humidity = d.optDoubleOrNull("relative_humidity"),
                    windMs = d.optDoubleOrNull("wind_speed"),
                    cloud = d.optDoubleOrNull("cloud_area_fraction"),
                    precip = p1?.optDoubleOrNull("precipitation_amount"),
                )
            )
        }
        return out
    }

    /** Şehre en yakın havalimanının son METAR gözlemi (150 dakikadan eski ise yok sayılır). */
    private fun fetchMetar(city: City): MetarObs? {
        val d = 0.8
        val url = "https://aviationweather.gov/api/data/metar" +
            "?bbox=${city.lat - d},${city.lon - d},${city.lat + d},${city.lon + d}&format=json"
        val text = httpGet(url).trim()
        if (text.isEmpty() || !text.startsWith("[")) return null
        val arr = JSONArray(text)
        val nowSec = System.currentTimeMillis() / 1000L
        var best: JSONObject? = null
        var bestD = Double.MAX_VALUE
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            if (!o.has("lat") || !o.has("lon")) continue
            val obs = o.optLong("obsTime", nowSec)
            if (nowSec - obs > 150 * 60) continue
            val dist = haversineKm(city.lat, city.lon, o.getDouble("lat"), o.getDouble("lon"))
            if (dist < bestD) {
                bestD = dist
                best = o
            }
        }
        val o = best ?: return null
        val slp = o.optDoubleOrNull("slp")
        val altim = o.optDoubleOrNull("altim")
        val pressure = slp ?: altim?.let { if (it < 100.0) it * 33.8639 else it }
        val wspdKt = o.optDoubleOrNull("wspd")
        return MetarObs(
            station = o.optString("icaoId", "METAR"),
            distKm = bestD,
            temp = o.optDoubleOrNull("temp"),
            dew = o.optDoubleOrNull("dewp"),
            windKmh = wspdKt?.times(1.852),
            pressure = pressure,
        )
    }

    private fun blend(om: Om, met: List<MetPoint>?, metar: MetarObs?, wo: Double, wm: Double, wr: Double): Weather {
        val base = om.w
        val c = base.current
        val nowH = System.currentTimeMillis() / 3_600_000L

        val metMap = HashMap<Long, MetPoint>()
        met?.forEach { metMap[it.epochH] = it }
        val metNow = met?.minByOrNull { abs(it.epochH - nowH) }?.takeIf { abs(it.epochH - nowH) <= 2 }

        // METAR gözlemi şehre uzaksa ağırlığı azalır (100 km'de %15'e kadar)
        val rw = if (metar != null) wr * (1.0 - metar.distKm / 100.0).coerceIn(0.15, 1.0) else 0.0
        val metarT = metar?.temp
        val metarDew = metar?.dew

        // ---- sıcaklık
        val tl = ArrayList<Pair<Double, Double>>()
        tl.addIf(c.temp, wo)
        tl.addIf(metNow?.temp, wm)
        tl.addIf(metarT, rw)
        val srcs = ArrayList<SrcTemp>()
        if (wo > 0.0) srcs.add(SrcTemp("Open-Meteo", c.temp, wo))
        val mt = metNow?.temp
        if (mt != null && wm > 0.0) srcs.add(SrcTemp("met.no", mt, wm))
        if (metar != null && metarT != null && rw > 0.0) srcs.add(SrcTemp("METAR ${metar.station}", metarT, rw))
        val temp = wavg(tl) ?: c.temp

        // ---- nem
        val hl = ArrayList<Pair<Double, Double>>()
        hl.addIf(c.humidity.toDouble(), wo)
        hl.addIf(metNow?.humidity, wm)
        if (metarT != null && metarDew != null) hl.addIf(relHumidity(metarT, metarDew), rw)
        val humidity = (wavg(hl) ?: c.humidity.toDouble()).roundToInt()

        // ---- rüzgâr
        val wl = ArrayList<Pair<Double, Double>>()
        wl.addIf(c.windKmh, wo)
        wl.addIf(metNow?.windMs?.times(3.6), wm)
        wl.addIf(metar?.windKmh, rw)
        val wind = wavg(wl) ?: c.windKmh

        // ---- basınç
        val pl = ArrayList<Pair<Double, Double>>()
        pl.addIf(c.pressure, wo)
        pl.addIf(metNow?.pressure, wm)
        pl.addIf(metar?.pressure, rw)
        val pressure = wavg(pl) ?: c.pressure

        // ---- bulut
        val cl = ArrayList<Pair<Double, Double>>()
        cl.addIf(c.cloud.toDouble(), wo)
        cl.addIf(metNow?.cloud, wm)
        val cloud = (wavg(cl) ?: c.cloud.toDouble()).roundToInt()

        // ---- yağış (mm/sa)
        val prl = ArrayList<Pair<Double, Double>>()
        prl.addIf(c.precip, wo)
        prl.addIf(metNow?.precip, wm)
        val precip = wavg(prl) ?: c.precip

        val code = adjustCode(c.code, precip, cloud, prl.size >= 2, 0.1)

        val current = Current(
            temp = temp,
            feels = c.feels + (temp - c.temp),
            humidity = humidity,
            windKmh = wind,
            windDir = c.windDir,
            gustKmh = c.gustKmh,
            pressure = pressure,
            cloud = cloud,
            precip = precip,
            code = code,
            isDay = c.isDay,
        )

        // ---- saatlik
        val hours = base.hours.map { h ->
            val mp = metMap[h.epochH]
            val t2 = ArrayList<Pair<Double, Double>>()
            t2.addIf(h.temp, wo)
            t2.addIf(mp?.temp, wm)
            val p2 = ArrayList<Pair<Double, Double>>()
            p2.addIf(h.precip, wo)
            p2.addIf(mp?.precip, wm)
            val b2 = ArrayList<Pair<Double, Double>>()
            b2.addIf(h.pressure, wo)
            b2.addIf(mp?.pressure, wm)
            val precipH = wavg(p2) ?: h.precip
            h.copy(
                temp = wavg(t2) ?: h.temp,
                precip = precipH,
                pressure = wavg(b2) ?: h.pressure,
                code = adjustCode(h.code, precipH, 70, p2.size >= 2, 0.2),
            )
        }

        // ---- günlük (met.no saatlik kapsadığı günlerde min/maks ortalaması)
        val byDate = HashMap<String, MutableList<Double>>()
        met?.forEach { p ->
            val t = p.temp
            if (t != null) byDate.getOrPut(dateOf(p.epochH, om.offsetSec)) { ArrayList() }.add(t)
        }
        val days = base.days.mapIndexed { idx, d ->
            val list = byDate[d.date]
            if (idx > 0 && list != null && list.size >= 20 && wm > 0.0) {
                d.copy(
                    min = wavg(listOf(d.min to wo, list.min() to wm)) ?: d.min,
                    max = wavg(listOf(d.max to wo, list.max() to wm)) ?: d.max,
                )
            } else {
                d
            }
        }

        val p0 = hours.getOrNull(0)?.pressure
        val p3 = hours.getOrNull(3)?.pressure
        val trend = if (p0 != null && p3 != null) p3 - p0 else null

        return Weather(
            current = current,
            nowTime = base.nowTime,
            hours = hours,
            days = days,
            updated = base.updated,
            uvNow = base.uvNow,
            sources = srcs,
            pressureTrend = trend,
        )
    }

    // ---------------------------------------------------------------- ek veriler

    /** Önümüzdeki 2 saat için yağış özeti (15 dakikalık Open-Meteo verisi). */
    fun nowcastText(city: City): String? {
        val url = "https://api.open-meteo.com/v1/forecast?latitude=${city.lat}&longitude=${city.lon}" +
            "&minutely_15=precipitation&forecast_minutely_15=8&timezone=auto"
        val m = JSONObject(httpGet(url)).getJSONObject("minutely_15")
        val p = m.getJSONArray("precipitation")
        val vals = (0 until p.length()).map { p.optDouble(it, 0.0) }
        if (vals.isEmpty()) return null
        val first = vals.indexOfFirst { it >= 0.1 }
        return when {
            first == -1 -> "Önümüzdeki 2 saatte yağış beklenmiyor"
            first == 0 && vals.all { it >= 0.1 } -> "Önümüzdeki 2 saat boyunca yağış sürecek"
            first == 0 -> {
                val stop = vals.indexOfFirst { it < 0.1 }
                "Yağış var, yaklaşık ${stop * 15} dk sonra duracak"
            }
            else -> "Yaklaşık ${first * 15} dk sonra yağış başlayacak"
        }
    }

    fun fetchAqi(city: City): Aqi? {
        val url = "https://air-quality-api.open-meteo.com/v1/air-quality" +
            "?latitude=${city.lat}&longitude=${city.lon}&current=european_aqi,pm10,pm2_5&timezone=auto"
        val cur = JSONObject(httpGet(url)).getJSONObject("current")
        val eu = cur.optDouble("european_aqi", Double.NaN)
        if (eu.isNaN()) return null
        return Aqi(eu.roundToInt(), cur.optDouble("pm2_5", 0.0), cur.optDouble("pm10", 0.0))
    }

    fun geocode(query: String): List<City> {
        val q = URLEncoder.encode(query, "UTF-8")
        val root = JSONObject(httpGet("https://geocoding-api.open-meteo.com/v1/search?name=$q&count=8&language=tr&format=json"))
        val arr = root.optJSONArray("results") ?: return emptyList()
        val out = ArrayList<City>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val admin = o.optString("admin1")
            val country = o.optString("country_code")
            val label = buildString {
                append(o.getString("name"))
                if (admin.isNotEmpty()) append(", ").append(admin)
                if (country.isNotEmpty()) append(" (").append(country).append(")")
            }
            out.add(City(label, o.getDouble("latitude"), o.getDouble("longitude")))
        }
        return out
    }

    /** NOAA SWPC gezegensel Kp indeksi: gözlenen + önümüzdeki 3 günün tahmini. */
    fun fetchKp(): List<KpPoint> {
        val arr = JSONArray(httpGet("https://services.swpc.noaa.gov/products/noaa-planetary-k-index-forecast.json"))
        val out = ArrayList<KpPoint>()
        for (i in 0 until arr.length()) {
            val row = arr.opt(i)
            val t: String
            val k: String
            val kind: String
            when (row) {
                is JSONObject -> {
                    t = row.optString("time_tag")
                    k = row.optString("kp")
                    kind = row.optString("observed")
                }
                is JSONArray -> {
                    t = row.optString(0)
                    k = row.optString(1)
                    kind = row.optString(2)
                }
                else -> continue
            }
            val ms = parseUtcMs(t) ?: continue
            val kp = k.toDoubleOrNull() ?: continue
            out.add(KpPoint(ms, kp, kind != "predicted"))
        }
        out.sortBy { it.timeMs }
        return out
    }

    // ---------------------------------------------------------------- depremler

    fun fetchQuakes(s: Settings, city: City): List<Quake> {
        val hours = s.int("qHours").coerceAtLeast(1)
        val radius = s.int("qRadius").coerceAtLeast(10)
        val mag = s.int("qMinMag") / 10.0
        if (s.str("qSource") == "afad") {
            try {
                return quakesAfad(city, hours, radius, mag)
            } catch (e: Exception) {
                // AFAD'a ulaşılamazsa USGS'ye düş
            }
        }
        return quakesUsgs(city, hours, radius, mag)
    }

    private fun quakesUsgs(city: City, hours: Int, radius: Int, mag: Double): List<Quake> {
        val fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss")
        val start = Instant.now().minusSeconds(hours * 3600L).atZone(ZoneOffset.UTC).format(fmt)
        val magS = String.format(Locale.US, "%.1f", mag)
        val url = "https://earthquake.usgs.gov/fdsnws/event/1/query?format=geojson" +
            "&latitude=${city.lat}&longitude=${city.lon}&maxradiuskm=$radius" +
            "&minmagnitude=$magS&starttime=$start&orderby=time&limit=50"
        val feats = JSONObject(httpGet(url)).optJSONArray("features") ?: return emptyList()
        val out = ArrayList<Quake>()
        for (i in 0 until feats.length()) {
            val f = feats.getJSONObject(i)
            val p = f.getJSONObject("properties")
            val g = f.getJSONObject("geometry").getJSONArray("coordinates")
            val lon = g.getDouble(0)
            val lat = g.getDouble(1)
            out.add(
                Quake(
                    id = f.optString("id"),
                    timeMs = p.optLong("time"),
                    mag = p.optDouble("mag", 0.0),
                    place = p.optString("place", "Bilinmiyor"),
                    lat = lat,
                    lon = lon,
                    depthKm = g.optDouble(2, 0.0),
                    distKm = haversineKm(city.lat, city.lon, lat, lon),
                )
            )
        }
        return out
    }

    private fun quakesAfad(city: City, hours: Int, radius: Int, mag: Double): List<Quake> {
        val fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss")
        val now = Instant.now()
        val start = now.minusSeconds((hours + 4) * 3600L).atZone(ZoneOffset.UTC).format(fmt)
        val end = now.plusSeconds(4 * 3600L).atZone(ZoneOffset.UTC).format(fmt)
        // Büyüklük ve mesafe süzgeci aşağıda yerelde uygulanır.
        val url = "https://deprem.afad.gov.tr/apiv2/event/filter?start=$start&end=$end&orderby=timedesc"
        val text = httpGet(url).trim()
        val arr: JSONArray = if (text.startsWith("[")) {
            JSONArray(text)
        } else {
            val o = JSONObject(text)
            o.optJSONArray("result") ?: o.optJSONArray("events") ?: JSONArray()
        }
        val cutoff = System.currentTimeMillis() - hours * 3_600_000L
        val out = ArrayList<Quake>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val date = o.optString("eventDate").ifEmpty { o.optString("date") }
            val t = parseUtcMs(date) ?: continue
            if (t < cutoff) continue
            val m = o.optString("magnitude").toDoubleOrNull() ?: continue
            if (m < mag) continue
            val la = o.optString("latitude").toDoubleOrNull() ?: continue
            val lo = o.optString("longitude").toDoubleOrNull() ?: continue
            val dist = haversineKm(city.lat, city.lon, la, lo)
            if (dist > radius) continue
            val place = o.optString("location").ifEmpty { o.optString("title") }.ifEmpty { "Türkiye" }
            out.add(
                Quake(
                    id = o.optString("eventID").ifEmpty { "$date-$la-$lo" },
                    timeMs = t,
                    mag = m,
                    place = place,
                    lat = la,
                    lon = lo,
                    depthKm = o.optString("depth").toDoubleOrNull() ?: 0.0,
                    distKm = dist,
                )
            )
        }
        out.sortByDescending { it.timeMs }
        return out
    }
}

/** Open-Meteo WMO hava kodunu (emoji, Türkçe açıklama) çiftine çevirir. */
fun describe(code: Int, isDay: Boolean): Pair<String, String> = when (code) {
    0 -> (if (isDay) "☀️" else "🌙") to "Açık"
    1 -> (if (isDay) "🌤️" else "🌙") to "Çoğunlukla açık"
    2 -> "⛅" to "Parçalı bulutlu"
    3 -> "☁️" to "Kapalı"
    45, 48 -> "🌫️" to "Sisli"
    51, 53, 55 -> "🌦️" to "Çisenti"
    56, 57 -> "🌧️" to "Donan çisenti"
    61 -> "🌧️" to "Hafif yağmurlu"
    63 -> "🌧️" to "Yağmurlu"
    65 -> "🌧️" to "Şiddetli yağmurlu"
    66, 67 -> "🌧️" to "Donan yağmur"
    71 -> "🌨️" to "Hafif karlı"
    73 -> "🌨️" to "Karlı"
    75 -> "❄️" to "Yoğun kar"
    77 -> "🌨️" to "Kar taneleri"
    80 -> "🌦️" to "Hafif sağanak"
    81 -> "🌧️" to "Sağanak"
    82 -> "🌧️" to "Şiddetli sağanak"
    85, 86 -> "🌨️" to "Kar sağanağı"
    95 -> "⛈️" to "Gök gürültülü fırtına"
    96, 99 -> "⛈️" to "Dolulu fırtına"
    else -> "☁️" to "Bilinmiyor"
}
