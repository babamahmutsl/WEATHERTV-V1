package com.example.havatv

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private sealed class AItem
private class AHeader(val title: String) : AItem()
private class AInfo(val text: String) : AItem()
private class AToggle(val key: String, val label: String) : AItem()
private class AChoice(val key: String, val label: String, val options: List<Pair<String, String>>) : AItem()
private class ANum(
    val key: String,
    val label: String,
    val min: Int,
    val max: Int,
    val step: Int,
    val unit: String = "",
    val tenths: Boolean = false,
    val zeroLabel: String? = null,
) : AItem()
private class AAction(val label: String, val value: String, val run: () -> Unit) : AItem()

private fun numText(n: ANum, v: Int): String =
    if (v == 0 && n.zeroLabel != null) n.zeroLabel
    else if (n.tenths) fmt1(v / 10.0) + n.unit
    else "$v${n.unit}"

/** Yönetici konsolu: uygulamadaki her ayar buradan değiştirilir. Sol/sağ tuşları değeri değiştirir. */
@Composable
fun AdminScreen(
    s: Settings,
    onCity: () -> Unit,
    onSearch: () -> Unit,
    onDream: () -> Unit,
    onRefresh: () -> Unit,
    onTestAlarm: () -> Unit,
    onRainTest: (Int) -> Unit,
) {
    val entries = listOf<AItem>(
        AHeader("📍 Konum"),
        AAction("Şehir seç", s.str("cityName"), onCity),
        AAction("Şehir ara (dünya geneli)", "", onSearch),

        AHeader("🔀 Veri kaynakları (ağırlıklı ortalama)"),
        AInfo("Sıcaklık, nem, rüzgâr, basınç ve yağış; Open-Meteo, met.no ve METAR değerlerinin ağırlıklı ortalamasıdır. Hepsi eşitse düz ortalama alınır."),
        ANum("wOm", "Open-Meteo ağırlığı", 0, 100, 10, "%", zeroLabel = "Kapalı"),
        ANum("wMet", "met.no ağırlığı", 0, 100, 10, "%", zeroLabel = "Kapalı"),
        ANum("wMetar", "METAR (havalimanı) ağırlığı", 0, 100, 10, "%", zeroLabel = "Kapalı"),
        AInfo("METAR istasyonu şehre uzaksa ağırlığı otomatik azalır. Open-Meteo kapalı olsa bile tahmin iskeleti ve yağış ihtimali ondan gelir."),
        AToggle("tSources", "Kaynak sıcaklıklarını ekranda göster"),

        AHeader("📏 Birimler"),
        AChoice("tempUnit", "Sıcaklık", listOf("C" to "°C", "F" to "°F")),
        AChoice("windUnit", "Rüzgâr", listOf("kmh" to "km/sa", "ms" to "m/s")),
        AChoice("pressUnit", "Basınç", listOf("hpa" to "hPa", "mmhg" to "mmHg")),

        AHeader("🎨 Görünüm"),
        ANum("uiScale", "Yazı boyutu", 70, 150, 10, "%"),
        AToggle("liveBg", "Canlı manzara animasyonu"),
        AToggle("keepOn", "Ekranı açık tut"),

        AHeader("🕒 Tahmin"),
        ANum("forecastDays", "Günlük tahmin gün sayısı", 3, 10, 1, " gün"),
        ANum("hourStep", "Saatlik tahmin aralığı", 1, 6, 1, " saat"),
        ANum("hourCount", "Saatlik tahmin kutu sayısı", 4, 12, 1),
        ANum("refreshMin", "Otomatik yenileme", 5, 60, 5, " dk"),

        AHeader("🌤 Hava ekranında gösterilecekler"),
        AToggle("tNowcast", "Yağış beklentisi (önümüzdeki 2 saat)"),
        AToggle("tFeels", "Hissedilen sıcaklık"),
        AToggle("tHumidity", "Nem"),
        AToggle("tWind", "Rüzgâr ve hamle"),
        AToggle("tPressure", "Basınç ve eğilimi"),
        AToggle("tUv", "UV indeksi"),
        AToggle("tAqi", "Hava kalitesi"),
        AToggle("tSun", "Gündoğumu / günbatımı"),
        AToggle("tMoon", "Ay evresi"),
        AToggle("tKp", "Manyetik alan (Kp)"),

        AHeader("📡 Radar"),
        AChoice("radarBase", "Harita", listOf("dark" to "Koyu", "light" to "Açık")),
        AChoice(
            "radarColor", "Renk şeması",
            listOf(
                "0" to "Siyah-beyaz", "1" to "Orijinal", "2" to "Evrensel mavi", "3" to "TITAN",
                "4" to "TWC", "5" to "Meteored", "6" to "NEXRAD", "7" to "Gökkuşağı", "8" to "Dark Sky",
            ),
        ),
        ANum("radarOpacity", "Radar saydamlığı", 20, 100, 10, "%"),
        ANum("radarSpeed", "Animasyon hızı (kare süresi)", 200, 1500, 100, " ms"),
        ANum("radarZoom", "Başlangıç yakınlığı", 3, 9, 1),
        AToggle("radarSmooth", "Yumuşatılmış görüntü"),
        AToggle("radarSnow", "Karı ayrı renkte göster"),

        AHeader("🔔 Alarmlar"),
        AToggle("alertsOn", "Alarm sistemi"),
        AToggle("alertSound", "Alarm sesi"),
        ANum("alertCheckMin", "Kontrol sıklığı", 1, 30, 1, " dk"),
        AAction("Alarmı test et", "", onTestAlarm),

        AHeader("🌍 Deprem alarmı"),
        AToggle("aQuake", "Deprem alarmı"),
        AChoice("qSource", "Kaynak", listOf("afad" to "AFAD (Türkiye)", "usgs" to "USGS (dünya)")),
        ANum("qMinMag", "En küçük büyüklük", 10, 70, 5, "", tenths = true),
        ANum("qRadius", "Uzaklık", 50, 1000, 50, " km"),
        ANum("qHours", "Son kaç saat", 1, 24, 1, " saat"),

        AHeader("⛈ Hava alarmları"),
        AToggle("aWind", "Şiddetli rüzgâr"),
        ANum("wGust", "  Hamle eşiği", 40, 150, 5, " km/sa"),
        AToggle("aRain", "Şiddetli yağış"),
        ANum("rMm", "  Yağış eşiği", 5, 60, 5, " mm/sa"),
        AToggle("aHeat", "Aşırı sıcak"),
        ANum("heatC", "  Sıcaklık eşiği", 30, 50, 1, "°C"),
        AToggle("aCold", "Aşırı soğuk"),
        ANum("coldC", "  Sıcaklık eşiği", -30, 0, 1, "°C"),
        AToggle("aStorm", "Gök gürültülü fırtına"),
        AToggle("aSnow", "Yoğun kar"),
        AToggle("aGeo", "Manyetik fırtına"),
        ANum("geoKp", "  Kp eşiği", 4, 9, 1),
        AToggle("aAqi", "Kötü hava kalitesi"),
        ANum("aqiMax", "  Hava kalitesi eşiği", 40, 140, 10),

        AHeader("🖥 Ekran koruyucu"),
        AInfo("HavaTV, TV'nin Ayarlar > Ekran koruyucu listesinde görünür. Başlama zamanını (ör. 5 dakika) orada seçersin."),
        AAction("Ekran koruyucu ayarlarını aç", "", onDream),
        AToggle("rainSound", "Yağmurlu havada yağmur sesi (hafif/şiddetli)"),
        ANum("rainVol", "Yağmur sesi seviyesi", 10, 100, 10, "%"),
        AAction("🌧 Hafif yağmur sesini dene", "", { onRainTest(1) }),
        AAction("⛈ Şiddetli yağmur sesini dene", "", { onRainTest(2) }),
        AAction("⏹ Sesi durdur", "", { onRainTest(0) }),

        AHeader("🛠 Sistem"),
        AAction("Verileri şimdi yenile", "", onRefresh),
        AAction("Tüm ayarları sıfırla (şehir kalır)", "", { s.reset() }),
        AInfo("HavaTV 0.2.0 · Veriler: Open-Meteo, met.no, aviationweather.gov, RainViewer, NOAA SWPC, AFAD, USGS"),
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        items(entries) { item ->
            when (item) {
                is AHeader -> Text(
                    item.title,
                    color = Color(0xFFFFE082),
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(top = 14.dp, bottom = 2.dp),
                )

                is AInfo -> Text(item.text, color = Color(0xB3FFFFFF), fontSize = 15.sp)

                is AToggle -> {
                    val on = s.bool(item.key)
                    FocusRow(
                        modifier = Modifier.fillMaxWidth(),
                        onClick = { s.set(item.key, !on) },
                        onLeft = { s.set(item.key, !on) },
                        onRight = { s.set(item.key, !on) },
                    ) { _ ->
                        Text(item.label, color = Color.White, fontSize = 20.sp, modifier = Modifier.weight(1f))
                        Text(
                            if (on) "AÇIK" else "KAPALI",
                            color = if (on) Color(0xFF81C784) else Color(0xFFEF9A9A),
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                        )
                    }
                }

                is AChoice -> {
                    val cur = s.str(item.key)
                    val idx = item.options.indexOfFirst { it.first == cur }.coerceAtLeast(0)
                    val n = item.options.size
                    FocusRow(
                        modifier = Modifier.fillMaxWidth(),
                        onClick = { s.set(item.key, item.options[(idx + 1) % n].first) },
                        onLeft = { s.set(item.key, item.options[(idx + n - 1) % n].first) },
                        onRight = { s.set(item.key, item.options[(idx + 1) % n].first) },
                    ) { _ ->
                        Text(item.label, color = Color.White, fontSize = 20.sp, modifier = Modifier.weight(1f))
                        Text("◀  ${item.options[idx].second}  ▶", color = Color(0xFF90CAF9), fontSize = 20.sp)
                    }
                }

                is ANum -> {
                    val cur = s.int(item.key)
                    FocusRow(
                        modifier = Modifier.fillMaxWidth(),
                        onClick = {
                            val nx = cur + item.step
                            s.set(item.key, if (nx > item.max) item.min else nx)
                        },
                        onLeft = { s.set(item.key, (cur - item.step).coerceAtLeast(item.min)) },
                        onRight = { s.set(item.key, (cur + item.step).coerceAtMost(item.max)) },
                    ) { _ ->
                        Text(item.label, color = Color.White, fontSize = 20.sp, modifier = Modifier.weight(1f))
                        Text("◀  ${numText(item, cur)}  ▶", color = Color(0xFF90CAF9), fontSize = 20.sp)
                    }
                }

                is AAction -> FocusRow(modifier = Modifier.fillMaxWidth(), onClick = item.run) { _ ->
                    Text(item.label, color = Color.White, fontSize = 20.sp, modifier = Modifier.weight(1f))
                    if (item.value.isNotEmpty()) {
                        Text(item.value, color = Color(0xFF90CAF9), fontSize = 20.sp)
                    }
                }
            }
        }
    }
}
