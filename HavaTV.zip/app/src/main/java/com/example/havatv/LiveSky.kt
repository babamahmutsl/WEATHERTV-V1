package com.example.havatv

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.lerp
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Gökyüzü sahnesini belirleyen özet bilgiler. */
class SkyInfo(
    val isDay: Boolean,
    val dayFrac: Float,
    val twilight: Float,
    val cloud: Float,
    val rain: Int, // 0 yok, 1 hafif, 2 şiddetli
    val snow: Boolean,
    val fog: Boolean,
    val thunder: Boolean,
)

fun skyInfo(w: Weather?): SkyInfo {
    if (w == null) return SkyInfo(true, 0.5f, 0f, 0.3f, 0, false, false, false)
    val c = w.current
    val d0 = w.days.firstOrNull()
    val now = minutesOf(w.nowTime)
    val sr = d0?.let { minutesOf(it.sunrise) } ?: 360
    val ss = d0?.let { minutesOf(it.sunset) } ?: 1080
    val isDay = now in sr..ss
    val frac = if (isDay) (now - sr).toFloat() / (ss - sr).coerceAtLeast(1) else 0f
    val tw = (1f - min(abs(now - sr), abs(now - ss)) / 60f).coerceIn(0f, 1f)
    val code = c.code
    val rain = when (code) {
        51, 53, 55, 61, 63, 80 -> 1
        56, 57, 65, 66, 67, 81, 82, 95, 96, 99 -> 2
        else -> 0
    }
    val snow = code in setOf(71, 73, 75, 77, 85, 86)
    val fog = code == 45 || code == 48
    val thunder = code in 95..99
    var cloud = c.cloud / 100f
    if (code >= 3) cloud = max(cloud, 0.8f)
    if (code == 2) cloud = max(cloud, 0.5f)
    return SkyInfo(isDay, frac, tw, cloud, rain, snow, fog, thunder)
}

private fun rnd(i: Int, k: Int): Float {
    val x = sin(i * 12.9898f + k * 78.233f) * 43758.5453f
    return x - floor(x)
}

private fun DrawScope.drawScene(si: SkyInfo, t: Float) {
    val w = size.width
    val h = size.height
    val twoPi = (2.0 * PI).toFloat()

    var top = if (si.isDay) Color(0xFF2F7BE0) else Color(0xFF070B1F)
    var bot = if (si.isDay) Color(0xFF9CCBFF) else Color(0xFF1B2A4A)
    top = lerp(top, Color(0xFF3A3F8F), si.twilight * 0.85f)
    bot = lerp(bot, Color(0xFFFF9A6B), si.twilight * 0.85f)
    val ov = (si.cloud * 0.85f + (if (si.rain > 0) 0.15f else 0f)).coerceIn(0f, 1f)
    top = lerp(top, if (si.isDay) Color(0xFF5E6B7A) else Color(0xFF121824), ov)
    bot = lerp(bot, if (si.isDay) Color(0xFFA9B4BF) else Color(0xFF2A3342), ov)

    drawRect(Brush.verticalGradient(listOf(top, bot)))

    // Yıldızlar
    if (!si.isDay) {
        repeat(70) { i ->
            val a = (0.35f + 0.65f * abs(sin(t * twoPi * (1 + i % 4) + i))) * (1f - si.cloud * 0.9f)
            drawCircle(
                Color.White.copy(alpha = a.coerceIn(0f, 1f)),
                1.2f + 1.8f * rnd(i, 9),
                Offset(rnd(i, 7) * w, rnd(i, 8) * h * 0.6f),
            )
        }
    }

    // Güneş / Ay
    if (si.isDay) {
        val f = si.dayFrac
        val cx = w * (0.12f + 0.76f * f)
        val cy = h * (0.58f - 0.40f * sin(f * PI.toFloat()))
        val r = h * 0.055f
        val c = Offset(cx, cy)
        drawCircle(
            Brush.radialGradient(listOf(Color(0x88FFE9A8), Color.Transparent), center = c, radius = r * 5f),
            radius = r * 5f, center = c, alpha = 1f - si.cloud * 0.8f,
        )
        drawCircle(Color(0xFFFFF3C4), r, c, alpha = 1f - si.cloud * 0.7f)
    } else {
        val c = Offset(w * 0.78f, h * 0.2f)
        val r = h * 0.045f
        drawCircle(
            Brush.radialGradient(listOf(Color(0x44DDE6FF), Color.Transparent), center = c, radius = r * 4f),
            radius = r * 4f, center = c, alpha = 1f - si.cloud * 0.8f,
        )
        drawCircle(Color(0xFFEFF3FF), r, c, alpha = 1f - si.cloud * 0.7f)
    }

    // Bulutlar (yavaşça sağa kayar)
    val nCloud = (2 + si.cloud * 7).toInt()
    repeat(nCloud) { i ->
        val k = 1 + i % 3
        val s = h * (0.05f + 0.05f * rnd(i, 4))
        val x = ((rnd(i, 3) + t * k) % 1f) * (w * 1.4f) - w * 0.2f
        val y = h * (0.10f + 0.38f * rnd(i, 1))
        val base = lerp(Color.White, Color(0xFF8E9AA8), (si.cloud * 0.9f).coerceIn(0f, 1f))
        val a = (if (si.isDay) 0.62f else 0.16f) * (0.65f + 0.35f * rnd(i, 2))
        val col = base.copy(alpha = a)
        drawCircle(col, s * 0.9f, Offset(x - 1.4f * s, y + 0.2f * s))
        drawCircle(col, s * 1.2f, Offset(x - 0.4f * s, y - 0.3f * s))
        drawCircle(col, s * 1.0f, Offset(x + 0.7f * s, y - 0.1f * s))
        drawCircle(col, s * 0.8f, Offset(x + 1.6f * s, y + 0.25f * s))
        drawOval(col, Offset(x - 2.2f * s, y + 0.1f * s), Size(4.6f * s, 0.9f * s))
    }

    if (si.fog) drawRect(Color(0x55DDE3EA))

    // Yağmur
    if (si.rain > 0) {
        val n = if (si.rain == 2) 150 else 70
        val col = Color(0x99B6D4FF)
        repeat(n) { i ->
            val k = 70 + (i % 3) * 15
            val x = rnd(i, 5) * w
            val y = ((rnd(i, 6) + t * k) % 1f) * (h * 1.1f) - h * 0.05f
            drawLine(col, Offset(x, y), Offset(x - 8f, y + 26f), strokeWidth = 2.2f)
        }
    }

    // Kar
    if (si.snow) {
        repeat(90) { i ->
            val k = 6 + i % 4
            val x = rnd(i, 5) * w + sin(t * twoPi * (2 + i % 3) + i) * 18f
            val y = ((rnd(i, 6) + t * k) % 1f) * h
            drawCircle(Color(0xCCFFFFFF), 2f + 3f * rnd(i, 7), Offset(x, y))
        }
    }

    // Şimşek
    if (si.thunder) {
        val tt = t * 90f
        val n = tt.toInt()
        if (n % 5 == 0 && tt - n < 0.08f) drawRect(Color(0x66FFFFFF))
    }

    // Tepeler
    val hill1 = if (si.snow) Color(0xFFCFD8E3) else lerp(bot, Color.Black, 0.6f)
    val hill2 = if (si.snow) Color(0xFFE6ECF3) else lerp(bot, Color.Black, 0.75f)
    val p1 = Path().apply {
        moveTo(0f, h)
        lineTo(0f, h * 0.82f)
        cubicTo(w * 0.25f, h * 0.72f, w * 0.45f, h * 0.90f, w * 0.70f, h * 0.80f)
        cubicTo(w * 0.85f, h * 0.74f, w * 0.95f, h * 0.80f, w, h * 0.78f)
        lineTo(w, h)
        close()
    }
    val p2 = Path().apply {
        moveTo(0f, h)
        lineTo(0f, h * 0.92f)
        cubicTo(w * 0.20f, h * 0.88f, w * 0.40f, h * 0.97f, w * 0.60f, h * 0.91f)
        cubicTo(w * 0.80f, h * 0.86f, w * 0.90f, h * 0.94f, w, h * 0.90f)
        lineTo(w, h)
        close()
    }
    drawPath(p1, hill1)
    drawPath(p2, hill2)

    // Yazıların okunması için hafif karartma
    drawRect(Brush.verticalGradient(listOf(Color(0x30000000), Color(0x59000000))))
}

/** YoWindow tarzı canlı manzara: gün saatine ve hava durumuna göre değişen animasyonlu gökyüzü. */
@Composable
fun LiveSky(w: Weather?, animate: Boolean, modifier: Modifier = Modifier) {
    val si = remember(w) { skyInfo(w) }
    if (animate) {
        val tr = rememberInfiniteTransition(label = "sky")
        val t by tr.animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(90_000, easing = LinearEasing), RepeatMode.Restart),
            label = "t",
        )
        Canvas(modifier) { drawScene(si, t) }
    } else {
        Canvas(modifier) { drawScene(si, 0f) }
    }
}
