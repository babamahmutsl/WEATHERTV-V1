package com.example.havatv

import android.service.dreams.DreamService
import android.view.View
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.time.LocalDate

/**
 * Ekran koruyucu. TV'nin Ayarlar > Ekran koruyucu listesinde "HavaTV" olarak görünür;
 * başlama süresini (ör. 5 dakika) sistem ayarından seçersin.
 */
class HavaDream : DreamService(), LifecycleOwner, SavedStateRegistryOwner {

    private val registry = LifecycleRegistry(this)
    private val controller = SavedStateRegistryController.create(this)

    override val lifecycle: Lifecycle get() = registry
    override val savedStateRegistry: SavedStateRegistry get() = controller.savedStateRegistry

    override fun onCreate() {
        super.onCreate()
        controller.performRestore(null)
        registry.currentState = Lifecycle.State.CREATED
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        isInteractive = false
        isFullscreen = true
        isScreenBright = true

        val decor: View = window.decorView
        decor.setViewTreeLifecycleOwner(this)
        decor.setViewTreeSavedStateRegistryOwner(this)

        val settings = Settings(getSharedPreferences("hava", MODE_PRIVATE))
        val compose = ComposeView(this)
        compose.setContent { DreamContent(settings) }
        setContentView(compose)
        registry.currentState = Lifecycle.State.STARTED
    }

    override fun onDreamingStarted() {
        super.onDreamingStarted()
        registry.currentState = Lifecycle.State.RESUMED
    }

    override fun onDreamingStopped() {
        RainSound.stop()
        registry.currentState = Lifecycle.State.STARTED
        super.onDreamingStopped()
    }

    override fun onDestroy() {
        registry.currentState = Lifecycle.State.DESTROYED
        super.onDestroy()
    }
}

@Composable
fun DreamContent(s: Settings) {
    val city = City(s.str("cityName"), s.dbl("cityLat"), s.dbl("cityLon"))
    var weather by remember { mutableStateOf<Weather?>(null) }
    var nowMs by remember { mutableLongStateOf(System.currentTimeMillis()) }

    LaunchedEffect(Unit) {
        while (true) {
            nowMs = System.currentTimeMillis()
            delay(15_000L)
        }
    }

    LaunchedEffect(city) {
        while (true) {
            val w = try {
                withContext(Dispatchers.IO) { WeatherApi.fetch(city, s) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                null
            }
            if (w != null) weather = w
            delay(if (w != null) 15 * 60_000L else 60_000L)
        }
    }

    // Yağmur sesi: hafif yağmurda sakin, şiddetli yağmurda yoğun
    val rainLevel = skyInfo(weather).rain
    LaunchedEffect(rainLevel, s.bool("rainSound"), s.int("rainVol")) {
        val lvl = if (s.bool("rainSound")) rainLevel else 0
        val vol = s.int("rainVol").coerceIn(0, 100) / 100f
        withContext(Dispatchers.Default) { RainSound.set(lvl, vol) }
    }
    DisposableEffect(Unit) {
        onDispose { RainSound.stop() }
    }

    // Ekran yanmasını önlemek için yazı yavaşça yana kayar (20 dakikalık döngü)
    val minute = ((nowMs / 60_000L) % 20).toInt()
    val drift = (if (minute < 10) minute else 20 - minute) * 8

    Box(modifier = Modifier.fillMaxSize()) {
        LiveSky(weather, s.bool("liveBg"), Modifier.fillMaxSize())

        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(start = (56 + drift).dp, bottom = 56.dp),
        ) {
            Text(fmtLocal(nowMs, "HH:mm"), color = Color.White, fontSize = 96.sp, fontWeight = FontWeight.Light)
            Text(dateTitle(LocalDate.now().toString()), color = Color(0xE6FFFFFF), fontSize = 26.sp)
            val w = weather
            if (w != null) {
                val c = w.current
                val (emoji, desc) = describe(c.code, c.isDay)
                Text(
                    "$emoji  ${s.fmtTempPrecise(c.temp)}  $desc",
                    color = Color.White,
                    fontSize = 38.sp,
                    modifier = Modifier.padding(top = 14.dp),
                )
                Text(city.name, color = Color(0xCCFFFFFF), fontSize = 20.sp)
            }
        }
    }
}
