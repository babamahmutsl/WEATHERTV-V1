package com.example.havatv

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.sqrt

/**
 * Yağmur sesi. Ses dosyası kullanmaz; çalışırken filtrelenmiş gürültü ve damla tıkırtılarından
 * üretilir, kesintisiz döngüye alınır. Seviye 1 = hafif yağmur, 2 = şiddetli yağmur.
 */
object RainSound {
    private const val RATE = 22050
    private var track: AudioTrack? = null
    private var level = 0
    private val cache = HashMap<Int, ShortArray>()

    @Synchronized
    fun set(newLevel: Int, volume: Float) {
        if (newLevel <= 0) {
            stop()
            return
        }
        if (newLevel == level && track != null) {
            try {
                track?.setVolume(volume)
            } catch (e: Exception) {
                // yok say
            }
            return
        }
        stop()
        try {
            val samples = cache.getOrPut(newLevel) { generate(newLevel >= 2) }
            val t = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(RATE)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(samples.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            t.write(samples, 0, samples.size)
            t.setLoopPoints(0, samples.size, -1)
            t.setVolume(volume)
            t.play()
            track = t
            level = newLevel
        } catch (e: Exception) {
            track = null
            level = 0
        }
    }

    @Synchronized
    fun stop() {
        try {
            track?.stop()
        } catch (e: Exception) {
            // yok say
        }
        try {
            track?.release()
        } catch (e: Exception) {
            // yok say
        }
        track = null
        level = 0
    }

    /** 6 saniyelik, başı sonuna dikişsiz bağlanan yağmur gürültüsü. */
    private fun generate(heavy: Boolean): ShortArray {
        val n = RATE * 6
        val fade = RATE / 2
        val total = n + fade
        val rnd = java.util.Random(if (heavy) 7L else 3L)

        val bodyA = if (heavy) 0.10f else 0.05f   // alçak, gürleyen gövde
        val bodyGain = if (heavy) 3.0f else 1.6f
        val hissGain = if (heavy) 0.55f else 0.35f // tıslama
        val dropRate = if (heavy) 0.020f else 0.004f // örnek başına damla ihtimali
        val gain = if (heavy) 0.55f else 0.45f

        val raw = FloatArray(total)
        var lpBody = 0f
        var lpHiss = 0f
        var dropEnv = 0f
        for (i in 0 until total) {
            val w = rnd.nextFloat() * 2f - 1f
            lpBody += bodyA * (w - lpBody)
            lpHiss += 0.5f * (w - lpHiss)
            val hiss = w - lpHiss
            if (rnd.nextFloat() < dropRate) dropEnv = 0.3f + 0.7f * rnd.nextFloat()
            val drop = dropEnv * (rnd.nextFloat() * 2f - 1f) * 0.8f
            dropEnv *= 0.85f
            raw[i] = lpBody * bodyGain + hiss * hissGain + drop
        }

        val out = ShortArray(n)
        for (i in 0 until n) {
            val v = if (i < fade) {
                val t = i / fade.toFloat()
                raw[i] * sqrt(t) + raw[n + i] * sqrt(1f - t)
            } else {
                raw[i]
            }
            val x = (v * gain).coerceIn(-1f, 1f)
            out[i] = (x * 32767f).toInt().toShort()
        }
        return out
    }
}
