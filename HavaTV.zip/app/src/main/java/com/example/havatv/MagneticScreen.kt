package com.example.havatv

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun MagneticScreen(d: DataHolder) {
    val list = d.kp
    if (list == null || list.isEmpty()) {
        CenterMessage("Manyetik alan verisi alınıyor…\n(NOAA Uzay Havası Tahmin Merkezi)")
        return
    }
    val now = System.currentTimeMillis()
    val cur = list.lastOrNull { it.timeMs <= now } ?: list.first()
    val window = list.filter { it.timeMs >= now - 24 * 3_600_000L && it.timeMs <= now + 72 * 3_600_000L }
    val peak = window.filter { it.timeMs > now }.maxByOrNull { it.kp }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(40.dp)) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Gezegensel Kp indeksi", color = Color(0xCCFFFFFF), fontSize = 18.sp)
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(
                        fmt1(cur.kp),
                        color = kpColor(cur.kp),
                        fontSize = 90.sp,
                        fontWeight = FontWeight.Light,
                    )
                    Text(
                        "   ${kpLabel(cur.kp)}",
                        color = Color.White,
                        fontSize = 28.sp,
                        modifier = Modifier.padding(bottom = 16.dp),
                    )
                }
                if (peak != null) {
                    Text(
                        "Önümüzdeki 3 günün en yüksek tahmini: Kp ${fmt1(peak.kp)} · ${fmtLocal(peak.timeMs, "dd.MM HH:mm")} · ${kpLabel(peak.kp)}",
                        color = Color(0xE6FFFFFF),
                        fontSize = 18.sp,
                    )
                }
            }
            Column(modifier = Modifier.weight(1f)) {
                Text("NOAA fırtına ölçeği", color = Color(0xCCFFFFFF), fontSize = 18.sp)
                val rows = listOf(
                    Triple("G1", 5.0, "Hafif: zayıf şebeke dalgalanmaları, kutup bölgelerinde aurora"),
                    Triple("G2", 6.0, "Orta: yüksek enlemlerde şebeke uyarıları"),
                    Triple("G3", 7.0, "Kuvvetli: uydu ve radyo iletişiminde aksamalar"),
                    Triple("G4", 8.0, "Şiddetli: yaygın gerilim kontrol sorunları"),
                    Triple("G5", 9.0, "Aşırı: şebeke çökmesi riski, aurora çok güneye iner"),
                )
                rows.forEach { (g, k, text) ->
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 2.dp)) {
                        Box(
                            Modifier
                                .background(kpColor(k), RoundedCornerShape(6.dp))
                                .padding(horizontal = 8.dp, vertical = 1.dp)
                        ) {
                            Text(g, color = Color.Black, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.padding(start = 10.dp))
                        Text("Kp ${k.toInt()} · $text", color = Color(0xE6FFFFFF), fontSize = 15.sp)
                    }
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        Text(
            "Son 24 saat ve önümüzdeki 72 saat (3 saatlik aralıklar, açık renk = tahmin)",
            color = Color(0xCCFFFFFF),
            fontSize = 16.sp,
        )
        Spacer(Modifier.height(8.dp))

        Row(modifier = Modifier.fillMaxWidth().weight(1f)) {
            window.forEach { p ->
                val hour = fmtLocal(p.timeMs, "HH")
                Column(
                    modifier = Modifier.weight(1f).fillMaxHeight().padding(horizontal = 2.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.BottomCenter) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .fillMaxHeight((p.kp / 9.0).toFloat().coerceIn(0.03f, 1f))
                                .background(
                                    kpColor(p.kp).copy(alpha = if (p.observed) 1f else 0.55f),
                                    RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp),
                                )
                        )
                    }
                    Text(fmt1(p.kp), color = Color.White, fontSize = 12.sp, maxLines = 1, softWrap = false)
                    Text(hour, color = Color(0xB3FFFFFF), fontSize = 12.sp, maxLines = 1, softWrap = false)
                    Text(
                        if (hour == "00") fmtLocal(p.timeMs, "dd.MM") else " ",
                        color = Color(0xFFFFE082),
                        fontSize = 11.sp,
                        maxLines = 1,
                        softWrap = false,
                    )
                }
            }
        }

        Text(
            "Veri: NOAA SWPC. Manyetik fırtınaların insan sağlığına etkisi konusunda bilimsel kanıt sınırlıdır; asıl etkiler elektrik şebekesi, uydu ve radyo sistemleri üzerindedir.",
            color = Color(0x99FFFFFF),
            fontSize = 13.sp,
            modifier = Modifier.padding(top = 6.dp),
        )
    }
}
