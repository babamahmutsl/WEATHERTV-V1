package com.example.havatv

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Kumandayla odaklanılabilen düğme. Odaktayken beyaz dolar. */
@Composable
fun TvButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    autoFocus: Boolean = false,
    accent: Color? = null,
    focusRequester: FocusRequester = remember { FocusRequester() },
    fontSize: TextUnit = 20.sp,
) {
    var focused by remember { mutableStateOf(false) }
    Box(
        modifier = modifier
            .focusRequester(focusRequester)
            .onFocusChanged { focused = it.isFocused }
            .clip(RoundedCornerShape(12.dp))
            .background(if (focused) Color.White else (accent ?: Color(0x33FFFFFF)))
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 9.dp)
    ) {
        Text(text, color = if (focused) Color.Black else Color.White, fontSize = fontSize)
    }
    if (autoFocus) {
        LaunchedEffect(Unit) {
            runCatching { focusRequester.requestFocus() }
        }
    }
}

/** Satır biçiminde odaklanılabilen alan; sol/sağ tuşlarına özel davranış verilebilir. */
@Composable
fun FocusRow(
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
    onLeft: (() -> Unit)? = null,
    onRight: (() -> Unit)? = null,
    content: @Composable RowScope.(focused: Boolean) -> Unit,
) {
    var focused by remember { mutableStateOf(false) }
    Row(
        modifier = modifier
            .onFocusChanged { focused = it.isFocused }
            .onPreviewKeyEvent { e ->
                if (e.type == KeyEventType.KeyDown) {
                    when (e.key) {
                        Key.DirectionLeft -> if (onLeft != null) {
                            onLeft()
                            true
                        } else {
                            false
                        }
                        Key.DirectionRight -> if (onRight != null) {
                            onRight()
                            true
                        } else {
                            false
                        }
                        else -> false
                    }
                } else {
                    false
                }
            }
            .clip(RoundedCornerShape(12.dp))
            .background(if (focused) Color(0xFF2F4A6B) else Color(0x1FFFFFFF))
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        this.content(focused)
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(
        text,
        color = Color(0xCCFFFFFF),
        fontSize = 20.sp,
        fontWeight = FontWeight.Medium,
        modifier = Modifier.padding(vertical = 6.dp),
    )
}
