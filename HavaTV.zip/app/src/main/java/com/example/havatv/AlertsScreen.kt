package com.example.havatv

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

@Composable
fun AlertsScreen(
    s: Settings,
    alerts: List<Alert>,
    quakes: List<Quake>?,
    onTest: () -> Unit,
    onStopSound: () -> Unit,
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                TvButton(text = "🔊 Alarmı test et", onClick = onTest, autoFocus = true)
                TvButton(text = "⏹ Sesi durdur", onClick = onStopSound)
            }
        }

        item {
            SectionTitle(
                if (!s.bool("alertsOn")) "Alarmlar kapalı · Yönetici konsolu → Alarmlar"
                else "Aktif uyarılar (${alerts.size})"
            )
        }

        if (s.bool("alertsOn") && alerts.isEmpty()) {
            item { Text("Şu an aktif uyarı yok ✓", color = Color(0xFFA5D6A7), fontSize = 22.sp) }
        }

        items(alerts) { a ->
            val bar = if (a.level >= 3) Color(0xFFE53935) else Color(0xFFFFB300)
            FocusRow(modifier = Modifier.fillMaxWidth(), onClick = {}) { _ ->
                Box(Modifier.width(6.dp).height(44.dp).background(bar))
                Spacer(Modifier.width(14.dp))
                Text(a.type.emoji, fontSize = 30.sp)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(a.title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Medium)
                    Text(a.detail, color = Color(0xCCFFFFFF), fontSize = 17.sp)
                }
            }
        }

        item {
            SectionTitle(
                "Son depremler · ${s.int("qRadius")} km · M${fmt1(s.int("qMinMag") / 10.0)}+ · ${s.int("qHours")} saat · " +
                    if (s.str("qSource") == "afad") "AFAD" else "USGS"
            )
        }

        if (quakes == null) {
            item { Text("Yükleniyor…", color = Color.White, fontSize = 18.sp) }
        } else if (quakes.isEmpty()) {
            item { Text("Bu kriterlere uyan deprem yok", color = Color(0xFFA5D6A7), fontSize = 20.sp) }
        } else {
            items(quakes.take(15)) { q ->
                FocusRow(modifier = Modifier.fillMaxWidth(), onClick = {}) { _ ->
                    Text(
                        "M${fmt1(q.mag)}",
                        color = if (q.mag >= 5.0) Color(0xFFFF7043) else if (q.mag >= 4.0) Color(0xFFFFCA28) else Color.White,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.width(90.dp),
                    )
                    Column(Modifier.weight(1f)) {
                        Text(q.place, color = Color.White, fontSize = 19.sp, maxLines = 1)
                        Text(
                            "${q.distKm.roundToInt()} km uzakta · derinlik ${q.depthKm.roundToInt()} km",
                            color = Color(0xB3FFFFFF),
                            fontSize = 15.sp,
                        )
                    }
                    Text(fmtLocal(q.timeMs, "dd.MM HH:mm"), color = Color(0xCCFFFFFF), fontSize = 17.sp)
                }
            }
        }
    }
}
