package com.example.havatv

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

@Composable
fun CenterMessage(text: String) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(text, color = Color.White, fontSize = 26.sp, textAlign = TextAlign.Center)
    }
}

@Composable
fun Detail(label: String, value: String) {
    Column {
        Text(label, color = Color(0xB3FFFFFF), fontSize = 16.sp)
        Text(value, color = Color.White, fontSize = 22.sp)
    }
}

@Composable
fun WeatherScreen(w: Weather?, d: DataHolder, s: Settings) {
    if (w == null) {
        val err = d.error
        CenterMessage(
            if (err != null) "Hava durumu alınamadı\n$err\nBir dakika içinde yeniden denenecek." else "Yükleniyor…"
        )
        return
    }

    val c = w.current
    val (emoji, desc) = describe(c.code, c.isDay)
    val today = w.days.firstOrNull()
    val nowMs = System.currentTimeMillis()

    // Gösterilecek ayrıntılar (Yönetici konsolundan açılıp kapanır)
    val details = ArrayList<Pair<String, String>>()
    if (s.bool("tFeels")) details.add("Hissedilen" to s.fmtTemp(c.feels))
    if (s.bool("tHumidity")) details.add("Nem" to "%${c.humidity}")
    if (s.bool("tWind")) {
        details.add("Rüzgâr" to "${s.fmtWind(c.windKmh)} ${windDirName(c.windDir)}")
        details.add("Hamle" to s.fmtWind(c.gustKmh))
    }
    if (s.bool("tPressure")) {
        val tr = w.pressureTrend
        val arrow = when {
            tr == null -> ""
            tr >= 0.5 -> " ↑"
            tr <= -0.5 -> " ↓"
            else -> " →"
        }
        details.add("Basınç" to (c.pressure?.let { s.fmtPressure(it) + arrow } ?: "—"))
    }
    details.add("Bulut" to "%${c.cloud}")
    if (s.bool("tUv")) details.add("UV" to uvLabel(w.uvNow))
    if (s.bool("tAqi")) {
        val a = d.aqi
        details.add("Hava kalitesi" to (a?.let { "${it.european} · ${aqiLabel(it.european)}" } ?: "—"))
    }
    if (s.bool("tSun") && today != null) {
        details.add("Gündoğumu" to today.sunrise.substring(11, 16))
        details.add("Günbatımı" to today.sunset.substring(11, 16))
    }
    if (s.bool("tMoon")) {
        val (me, mn) = moonPhase()
        details.add("Ay" to "$me $mn")
    }
    if (s.bool("tKp")) {
        val k = d.kp?.lastOrNull { it.timeMs <= nowMs }
        details.add("Manyetik alan" to (k?.let { "Kp ${fmt1(it.kp)} · ${kpLabel(it.kp)}" } ?: "—"))
    }

    val step = s.int("hourStep").coerceAtLeast(1)
    val count = s.int("hourCount").coerceIn(3, 12)
    val hourItems = w.hours.filterIndexed { i, _ -> i % step == 0 }.take(count)
    val dayItems = w.days.take(s.int("forecastDays").coerceIn(3, 10))

    Column(modifier = Modifier.fillMaxSize()) {
        Row(modifier = Modifier.weight(1f).fillMaxWidth()) {
            // Sol: anlık durum
            Column(modifier = Modifier.weight(1.2f), verticalArrangement = Arrangement.Center) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(emoji, fontSize = 60.sp)
                    Spacer(Modifier.width(16.dp))
                    Text(desc, color = Color.White, fontSize = 30.sp)
                }
                Text(
                    s.fmtTempPrecise(c.temp),
                    color = Color.White,
                    fontSize = 110.sp,
                    fontWeight = FontWeight.Light,
                )
                val nc = d.nowcast
                if (s.bool("tNowcast") && nc != null) {
                    Text("☔ $nc", color = Color(0xFFBFE0FF), fontSize = 20.sp)
                }
                if (s.bool("tSources") && w.sources.size > 1) {
                    val line = w.sources.joinToString("  ·  ") { "${it.name} ${s.fmtTemp(it.temp)}" }
                    Text(
                        "$line  →  ortalama ${s.fmtTempPrecise(c.temp)}",
                        color = Color(0xB3FFFFFF),
                        fontSize = 15.sp,
                        modifier = Modifier.padding(top = 4.dp),
                    )
                }
                Spacer(Modifier.height(14.dp))
                details.chunked(4).forEach { row ->
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(30.dp),
                        modifier = Modifier.padding(vertical = 5.dp),
                    ) {
                        row.forEach { (l, v) -> Detail(l, v) }
                    }
                }
            }

            // Sağ: günlük tahmin
            Column(modifier = Modifier.weight(0.8f), verticalArrangement = Arrangement.Center) {
                Text("${dayItems.size} Günlük Tahmin", color = Color(0xCCFFFFFF), fontSize = 18.sp)
                Spacer(Modifier.height(6.dp))
                dayItems.forEach { day ->
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(day.label, color = Color.White, fontSize = 21.sp, modifier = Modifier.weight(1f))
                        val p = day.rainProbMax
                        Text(
                            if (p != null && p >= 20) "💧%$p" else "",
                            color = Color(0xFF8CC4FF),
                            fontSize = 15.sp,
                            modifier = Modifier.width(66.dp),
                        )
                        Text(describe(day.code, true).first, fontSize = 24.sp)
                        Spacer(Modifier.width(14.dp))
                        Text(s.fmtTemp(day.min), color = Color(0xFF8CC4FF), fontSize = 21.sp, modifier = Modifier.width(60.dp))
                        Text(s.fmtTemp(day.max), color = Color(0xFFFFB38A), fontSize = 21.sp, modifier = Modifier.width(60.dp))
                    }
                }
            }
        }

        // Alt: saatlik tahmin
        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            hourItems.forEach { h ->
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0x26FFFFFF))
                        .padding(vertical = 10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(h.time.substring(11, 16), color = Color(0xCCFFFFFF), fontSize = 16.sp)
                    Text(describe(h.code, h.isDay).first, fontSize = 26.sp)
                    Text(s.fmtTemp(h.temp), color = Color.White, fontSize = 21.sp)
                    Text(
                        h.rainProb?.let { "💧%$it" } ?: " ",
                        color = Color(0xFF8CC4FF),
                        fontSize = 14.sp,
                    )
                }
            }
        }
    }
}
