package com.example.havatv

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun OverlayPanel(content: @Composable ColumnScope.() -> Unit) {
    Box(
        modifier = Modifier.fillMaxSize().background(Color(0xCC000000)),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            modifier = Modifier
                .width(640.dp)
                .fillMaxHeight(0.88f)
                .clip(RoundedCornerShape(20.dp))
                .background(Color(0xFF16202C))
                .padding(24.dp),
            content = content,
        )
    }
}

@Composable
fun CityPicker(current: String, onSelect: (City) -> Unit) {
    val index = Cities.all.indexOfFirst { it.name == current }.coerceAtLeast(0)
    val listState = rememberLazyListState(initialFirstVisibleItemIndex = (index - 3).coerceAtLeast(0))
    OverlayPanel {
        Text("Şehir seç", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(12.dp))
        LazyColumn(state = listState, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(Cities.all) { c ->
                TvButton(
                    text = if (c.name == current) "✓  ${c.name}" else c.name,
                    onClick = { onSelect(c) },
                    modifier = Modifier.fillMaxWidth(),
                    autoFocus = c.name == current,
                )
            }
        }
    }
}

@Composable
fun SearchOverlay(onSelect: (City) -> Unit) {
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<City>>(emptyList()) }
    var status by remember { mutableStateOf("Şehir adını yazıp Ara'ya bas") }
    val scope = rememberCoroutineScope()
    val fieldFocus = remember { FocusRequester() }

    fun doSearch() {
        if (query.trim().length < 2) return
        status = "Aranıyor…"
        scope.launch {
            val r = runCatching { withContext(Dispatchers.IO) { WeatherApi.geocode(query.trim()) } }
            r.onSuccess {
                results = it
                status = if (it.isEmpty()) "Sonuç bulunamadı" else ""
            }
            r.onFailure { status = "Arama başarısız: ${it.message}" }
        }
    }

    LaunchedEffect(Unit) {
        runCatching { fieldFocus.requestFocus() }
    }

    OverlayPanel {
        Text("Şehir ara", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(12.dp))
        BasicTextField(
            value = query,
            onValueChange = { query = it },
            singleLine = true,
            textStyle = TextStyle(color = Color.White, fontSize = 24.sp),
            cursorBrush = SolidColor(Color.White),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { doSearch() }),
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0x33FFFFFF))
                .padding(14.dp)
                .focusRequester(fieldFocus),
        )
        Spacer(Modifier.height(10.dp))
        TvButton(text = "🔍 Ara", onClick = { doSearch() })
        if (status.isNotEmpty()) {
            Text(status, color = Color(0xCCFFFFFF), fontSize = 18.sp, modifier = Modifier.padding(vertical = 8.dp))
        }
        Spacer(Modifier.height(6.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(results) { c ->
                TvButton(text = c.name, onClick = { onSelect(c) }, modifier = Modifier.fillMaxWidth())
            }
        }
    }
}

@Composable
fun AlertPopup(alerts: List<Alert>, onOk: () -> Unit) {
    val worst = alerts.maxOf { it.level }
    Box(
        modifier = Modifier.fillMaxSize().background(Color(0xCC000000)),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            modifier = Modifier
                .width(700.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(if (worst >= 3) Color(0xFF7F1D1D) else Color(0xFF7A4A0B))
                .padding(28.dp),
        ) {
            Text("⚠️ UYARI", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            alerts.take(4).forEach { a ->
                Text("${a.type.emoji}  ${a.title}", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Medium)
                Text(a.detail, color = Color(0xCCFFFFFF), fontSize = 20.sp)
                Spacer(Modifier.height(10.dp))
            }
            if (alerts.size > 4) {
                Text("+${alerts.size - 4} uyarı daha (Alarmlar ekranında)", color = Color(0xCCFFFFFF), fontSize = 18.sp)
                Spacer(Modifier.height(10.dp))
            }
            TvButton(text = "Tamam", onClick = onOk, autoFocus = true, fontSize = 24.sp)
        }
    }
}
