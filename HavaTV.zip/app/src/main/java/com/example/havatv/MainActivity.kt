package com.example.havatv

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val settings = Settings(getSharedPreferences("hava", MODE_PRIVATE))
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                HavaApp(settings)
            }
        }
    }

    override fun onDestroy() {
        AlarmPlayer.stop()
        RainSound.stop()
        super.onDestroy()
    }
}

enum class Screen(val title: String, val emoji: String) {
    WEATHER("Hava durumu", "🌤"),
    RADAR("Radar", "📡"),
    MAGNETIC("Manyetik fırtına", "🧲"),
    ALERTS("Alarmlar", "🔔"),
    ADMIN("Yönetici konsolu", "⚙️"),
}

@Composable
fun HavaApp(s: Settings) {
    val ctx = LocalContext.current
    val view = LocalView.current
    val data = remember { DataHolder() }
    var screen by remember { mutableStateOf(Screen.WEATHER) }
    var menuOpen by remember { mutableStateOf(false) }
    var overlay by remember { mutableStateOf<String?>(null) }
    var refreshTick by remember { mutableIntStateOf(0) }
    val menuFocus = remember { FocusRequester() }

    val city = City(s.str("cityName"), s.dbl("cityLat"), s.dbl("cityLon"))

    LaunchedEffect(s.bool("keepOn")) {
        view.keepScreenOn = s.bool("keepOn")
    }

    // Hava verisi: üç kaynağın ortalaması
    LaunchedEffect(city, s.int("wOm"), s.int("wMet"), s.int("wMetar"), refreshTick) {
        if (data.forCity != city.name) {
            data.weather = null
            data.nowcast = null
            data.aqi = null
            data.quakes = null
            data.forCity = city.name
        }
        while (true) {
            try {
                data.weather = withContext(Dispatchers.IO) { WeatherApi.fetch(city, s) }
                data.error = null
                data.offline = false
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (data.weather != null) data.offline = true else data.error = e.message ?: "Bağlantı hatası"
            }
            val nc = try {
                withContext(Dispatchers.IO) { WeatherApi.nowcastText(city) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                null
            }
            data.nowcast = nc
            val ok = data.error == null && !data.offline
            delay(if (ok) s.int("refreshMin").coerceAtLeast(1) * 60_000L else 60_000L)
        }
    }

    // Alarm kaynakları: manyetik alan, hava kalitesi, depremler
    LaunchedEffect(
        city, s.str("qSource"), s.int("qHours"), s.int("qRadius"), s.int("qMinMag"),
        s.int("alertCheckMin"), refreshTick,
    ) {
        while (true) {
            val kp = withContext(Dispatchers.IO) { runCatching { WeatherApi.fetchKp() }.getOrNull() }
            if (kp != null) data.kp = kp
            val aqi = withContext(Dispatchers.IO) { runCatching { WeatherApi.fetchAqi(city) }.getOrNull() }
            if (aqi != null) data.aqi = aqi
            val q = withContext(Dispatchers.IO) { runCatching { WeatherApi.fetchQuakes(s, city) }.getOrNull() }
            if (q != null) data.quakes = q
            delay(s.int("alertCheckMin").coerceAtLeast(1) * 60_000L)
        }
    }

    // Alarmlar
    val alerts = computeAlerts(s, data.weather, data.kp, data.quakes, data.aqi)
    val seen = s.seen()
    val fresh = alerts.filter { it.id !in seen }
    val freshKey = fresh.joinToString("|") { it.id }

    LaunchedEffect(freshKey) {
        if (fresh.isNotEmpty() && s.bool("alertSound")) {
            AlarmPlayer.start(ctx)
            delay(20_000L)
            AlarmPlayer.stop()
        } else {
            AlarmPlayer.stop()
        }
    }

    fun ackAlerts() {
        s.markSeen(fresh.map { it.id })
        AlarmPlayer.stop()
    }

    fun applyCity(c: City) {
        s.set("cityName", c.name)
        s.set("cityLat", c.lat)
        s.set("cityLon", c.lon)
        overlay = null
    }

    fun openDreamSettings() {
        val candidates = listOf("android.settings.DREAM_SETTINGS", android.provider.Settings.ACTION_SETTINGS)
        for (action in candidates) {
            try {
                ctx.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return
            } catch (e: Exception) {
                // sıradaki seçeneği dene
            }
        }
    }

    BackHandler(enabled = fresh.isNotEmpty() || overlay != null || menuOpen || screen != Screen.WEATHER) {
        when {
            fresh.isNotEmpty() -> ackAlerts()
            overlay != null -> overlay = null
            menuOpen -> menuOpen = false
            else -> screen = Screen.WEATHER
        }
    }

    // Kumanda odağı: Radar ve Alarmlar kendi düğmesine odaklanır, diğerlerinde ☰ düğmesine
    val screenOwnsFocus = screen == Screen.RADAR || screen == Screen.ALERTS
    LaunchedEffect(menuOpen, screen, overlay, fresh.isEmpty()) {
        if (!menuOpen && overlay == null && fresh.isEmpty() && !screenOwnsFocus) {
            runCatching { menuFocus.requestFocus() }
        }
    }

    val base = LocalDensity.current
    val scaled = Density(base.density, base.fontScale * s.int("uiScale").coerceIn(50, 200) / 100f)

    CompositionLocalProvider(LocalDensity provides scaled) {
        Box(modifier = Modifier.fillMaxSize()) {
            LiveSky(data.weather, s.bool("liveBg"), Modifier.fillMaxSize())

            if (overlay == null && fresh.isEmpty()) {
                Column(modifier = Modifier.fillMaxSize().padding(horizontal = 48.dp, vertical = 24.dp)) {
                    TopBar(
                        city = city,
                        screen = screen,
                        updated = data.weather?.updated,
                        offline = data.offline,
                        alertCount = alerts.size,
                        menuFocus = menuFocus,
                        onMenu = { menuOpen = true },
                        onCity = { overlay = "city" },
                    )
                    Spacer(Modifier.height(12.dp))
                    Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                        when (screen) {
                            Screen.WEATHER -> WeatherScreen(data.weather, data, s)
                            Screen.RADAR -> RadarScreen(s, city)
                            Screen.MAGNETIC -> MagneticScreen(data)
                            Screen.ALERTS -> AlertsScreen(
                                s = s,
                                alerts = alerts,
                                quakes = data.quakes,
                                onTest = { AlarmPlayer.start(ctx) },
                                onStopSound = { AlarmPlayer.stop() },
                            )
                            Screen.ADMIN -> AdminScreen(
                                s = s,
                                onCity = { overlay = "city" },
                                onSearch = { overlay = "search" },
                                onDream = { openDreamSettings() },
                                onRefresh = { refreshTick++ },
                                onTestAlarm = { AlarmPlayer.start(ctx) },
                                onRainTest = { RainSound.set(it, s.int("rainVol").coerceIn(0, 100) / 100f) },
                            )
                        }
                    }
                }
            }

            if (menuOpen && overlay == null && fresh.isEmpty()) {
                Drawer(
                    current = screen,
                    alertCount = alerts.size,
                    onPick = {
                        screen = it
                        menuOpen = false
                    },
                )
            }

            if (overlay == "city") CityPicker(current = city.name, onSelect = { applyCity(it) })
            if (overlay == "search") SearchOverlay(onSelect = { applyCity(it) })
            if (fresh.isNotEmpty()) AlertPopup(alerts = fresh, onOk = { ackAlerts() })
        }
    }
}

@Composable
fun TopBar(
    city: City,
    screen: Screen,
    updated: String?,
    offline: Boolean,
    alertCount: Int,
    menuFocus: FocusRequester,
    onMenu: () -> Unit,
    onCity: () -> Unit,
) {
    var clock by remember { mutableStateOf(fmtLocal(System.currentTimeMillis(), "HH:mm")) }
    LaunchedEffect(Unit) {
        while (true) {
            clock = fmtLocal(System.currentTimeMillis(), "HH:mm")
            delay(10_000L)
        }
    }

    Row(verticalAlignment = Alignment.CenterVertically) {
        TvButton(text = "☰", onClick = onMenu, focusRequester = menuFocus, fontSize = 26.sp)
        Spacer(Modifier.width(14.dp))
        TvButton(text = "📍 ${city.name}  ▾", onClick = onCity)
        Spacer(Modifier.width(18.dp))
        Text("${screen.emoji} ${screen.title}", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.weight(1f))
        if (alertCount > 0) {
            Text("🔔 $alertCount", color = Color(0xFFFFC107), fontSize = 22.sp)
            Spacer(Modifier.width(18.dp))
        }
        if (updated != null) {
            Text(
                "Güncelleme $updated" + if (offline) " (çevrimdışı)" else "",
                color = Color(0xB3FFFFFF),
                fontSize = 16.sp,
            )
            Spacer(Modifier.width(18.dp))
        }
        Text(clock, color = Color.White, fontSize = 30.sp)
    }
}

/** Sol üstteki ☰ düğmesiyle açılan menü. Yönetici konsolu en altta. */
@Composable
fun Drawer(current: Screen, alertCount: Int, onPick: (Screen) -> Unit) {
    Row(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .width(380.dp)
                .fillMaxHeight()
                .background(Color(0xF2101826))
                .padding(24.dp),
        ) {
            Text("HavaTV", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(24.dp))
            Screen.values().filter { it != Screen.ADMIN }.forEach { sc ->
                val badge = if (sc == Screen.ALERTS && alertCount > 0) "   ($alertCount)" else ""
                TvButton(
                    text = "${sc.emoji}  ${sc.title}$badge",
                    onClick = { onPick(sc) },
                    modifier = Modifier.fillMaxWidth(),
                    autoFocus = sc == current,
                    fontSize = 24.sp,
                )
                Spacer(Modifier.height(10.dp))
            }
            Spacer(Modifier.weight(1f))
            TvButton(
                text = "⚙️  Yönetici konsolu",
                onClick = { onPick(Screen.ADMIN) },
                modifier = Modifier.fillMaxWidth(),
                autoFocus = current == Screen.ADMIN,
                accent = Color(0x55FFB300),
                fontSize = 24.sp,
            )
        }
        Box(modifier = Modifier.weight(1f).fillMaxHeight().background(Color(0x66000000)))
    }
}
