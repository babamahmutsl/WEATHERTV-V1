package com.example.havatv

import androidx.compose.ui.graphics.Color
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import kotlin.math.roundToInt

fun Settings.fmtTemp(c: Double): String {
    val f = str("tempUnit") == "F"
    val v = if (f) c * 9.0 / 5.0 + 32.0 else c
    return "${v.roundToInt()}°" + if (f) "F" else ""
}

/** Ondalıklı sıcaklık, örn. "7,4°" (ortalama değerleri göstermek için). */
fun Settings.fmtTempPrecise(c: Double): String {
    val f = str("tempUnit") == "F"
    val v = if (f) c * 9.0 / 5.0 + 32.0 else c
    return String.format(java.util.Locale("tr"), "%.1f", v) + "°" + if (f) "F" else ""
}

fun Settings.fmtWind(kmh: Double): String =
    if (str("windUnit") == "ms") "${(kmh / 3.6).roundToInt()} m/s" else "${kmh.roundToInt()} km/sa"

fun Settings.fmtPressure(hpa: Double): String =
    if (str("pressUnit") == "mmhg") "${(hpa * 0.750062).roundToInt()} mmHg" else "${hpa.roundToInt()} hPa"

fun fmt1(d: Double): String = ((d * 10).roundToInt() / 10.0).toString()

private val dirNames = arrayOf("K", "KD", "D", "GD", "G", "GB", "B", "KB")

fun windDirName(deg: Int): String {
    val d = ((deg % 360) + 360) % 360
    return dirNames[((d / 45.0) + 0.5).toInt() % 8]
}

fun uvLabel(uv: Double): String {
    val t = when {
        uv < 3 -> "Düşük"
        uv < 6 -> "Orta"
        uv < 8 -> "Yüksek"
        uv < 11 -> "Çok yüksek"
        else -> "Aşırı"
    }
    return "${uv.roundToInt()} · $t"
}

fun aqiLabel(eaqi: Int): String = when {
    eaqi <= 20 -> "İyi"
    eaqi <= 40 -> "Makul"
    eaqi <= 60 -> "Orta"
    eaqi <= 80 -> "Kötü"
    eaqi <= 100 -> "Çok kötü"
    else -> "Aşırı kötü"
}

// ---- Manyetik fırtına (NOAA G ölçeği) ----

fun gScale(kp: Double): Int = when {
    kp >= 9.0 -> 5
    kp >= 8.0 -> 4
    kp >= 7.0 -> 3
    kp >= 6.0 -> 2
    kp >= 5.0 -> 1
    else -> 0
}

fun kpLabel(kp: Double): String = when (gScale(kp)) {
    5 -> "G5 Aşırı fırtına"
    4 -> "G4 Şiddetli fırtına"
    3 -> "G3 Kuvvetli fırtına"
    2 -> "G2 Orta fırtına"
    1 -> "G1 Hafif fırtına"
    else -> if (kp >= 4.0) "Hareketli" else "Sakin"
}

fun kpColor(kp: Double): Color = when {
    kp >= 9.0 -> Color(0xFFB71C1C)
    kp >= 8.0 -> Color(0xFFE53935)
    kp >= 7.0 -> Color(0xFFFF7043)
    kp >= 6.0 -> Color(0xFFFFA726)
    kp >= 5.0 -> Color(0xFFFFCA28)
    kp >= 4.0 -> Color(0xFFCDDC39)
    else -> Color(0xFF66BB6A)
}

// ---- Tarih ve saat ----

private val dayNames = arrayOf("Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi", "Pazar")
private val monthNames = arrayOf(
    "Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran",
    "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık",
)

fun dayName(date: LocalDate): String = dayNames[date.dayOfWeek.value - 1]

fun dateTitle(iso: String): String {
    val d = LocalDate.parse(iso.substring(0, 10))
    return "${dayName(d)}, ${d.dayOfMonth} ${monthNames[d.monthValue - 1]}"
}

/** "2026-10-29T09:15" -> dakika cinsinden gün içi saat (555). */
fun minutesOf(iso: String): Int = iso.substring(11, 13).toInt() * 60 + iso.substring(14, 16).toInt()

fun parseUtcMs(s: String): Long? = runCatching {
    LocalDateTime.parse(s.trim().removeSuffix("Z").replace(' ', 'T'))
        .toInstant(ZoneOffset.UTC)
        .toEpochMilli()
}.getOrNull()

fun fmtLocal(ms: Long, pattern: String): String =
    Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern(pattern))

/** Ay evresi: (emoji, ad). */
fun moonPhase(): Pair<String, String> {
    val synodic = 29.530588853
    val ref = LocalDate.of(2000, 1, 6).toEpochDay() // bilinen bir yeni ay
    val days = LocalDate.now().toEpochDay() - ref
    val age = ((days % synodic) + synodic) % synodic
    val idx = (((age / synodic) * 8) + 0.5).toInt() % 8
    val emojis = arrayOf("🌑", "🌒", "🌓", "🌔", "🌕", "🌖", "🌗", "🌘")
    val names = arrayOf(
        "Yeni ay", "Büyüyen hilal", "İlk dördün", "Büyüyen ay",
        "Dolunay", "Küçülen ay", "Son dördün", "Küçülen hilal",
    )
    return emojis[idx] to names[idx]
}
