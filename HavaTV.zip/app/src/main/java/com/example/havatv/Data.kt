package com.example.havatv

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Ekranların ortak kullandığı canlı veriler. */
class DataHolder {
    var weather by mutableStateOf<Weather?>(null)
    var error by mutableStateOf<String?>(null)
    var offline by mutableStateOf(false)
    var nowcast by mutableStateOf<String?>(null)
    var aqi by mutableStateOf<Aqi?>(null)
    var kp by mutableStateOf<List<KpPoint>?>(null)
    var quakes by mutableStateOf<List<Quake>?>(null)
    var forCity: String? = null
}
