package com.example.havatv

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.Ringtone
import android.media.RingtoneManager
import android.media.ToneGenerator
import kotlin.math.roundToInt

enum class AlertType(val emoji: String) {
    QUAKE("🌍"), WIND("💨"), RAIN("🌧️"), HEAT("🔥"), COLD("🥶"),
    STORM("⛈️"), SNOW("❄️"), GEO("🧲"), AQI("😷"),
}

data class Alert(
    val id: String,
    val type: AlertType,
    val title: String,
    val detail: String,
    val level: Int, // 1 bilgi, 2 uyarı, 3 tehlikeli
)

/** Ayarlardaki eşiklere göre şu an geçerli tüm uyarıları üretir. */
fun computeAlerts(s: Settings, w: Weather?, kp: List<KpPoint>?, quakes: List<Quake>?, aqi: Aqi?): List<Alert> {
    if (!s.bool("alertsOn")) return emptyList()
    val out = ArrayList<Alert>()

    if (w != null) {
        val next = w.hours.take(24)

        if (s.bool("aWind")) {
            val thr = s.int("wGust").toDouble()
            val h = next.maxByOrNull { it.gust }
            if (h != null && h.gust >= thr) {
                out.add(
                    Alert(
                        "wind-" + h.time.substring(0, 10), AlertType.WIND, "Şiddetli rüzgâr bekleniyor",
                        "Hamle ${s.fmtWind(h.gust)} · ${h.time.substring(11, 16)} civarı",
                        if (h.gust >= thr + 30) 3 else 2,
                    )
                )
            }
        }
        if (s.bool("aRain")) {
            val thr = s.int("rMm").toDouble()
            val h = next.maxByOrNull { it.precip }
            if (h != null && h.precip >= thr) {
                out.add(
                    Alert(
                        "rain-" + h.time.substring(0, 10), AlertType.RAIN, "Şiddetli yağış bekleniyor",
                        "${fmt1(h.precip)} mm/sa · ${h.time.substring(11, 16)} civarı",
                        if (h.precip >= thr * 2) 3 else 2,
                    )
                )
            }
        }
        if (s.bool("aHeat")) {
            val thr = s.int("heatC").toDouble()
            val h = next.maxByOrNull { it.temp }
            if (h != null && h.temp >= thr) {
                out.add(
                    Alert(
                        "heat-" + h.time.substring(0, 10), AlertType.HEAT, "Aşırı sıcak",
                        "${s.fmtTemp(h.temp)} · ${h.time.substring(11, 16)} civarı",
                        if (h.temp >= thr + 5) 3 else 2,
                    )
                )
            }
        }
        if (s.bool("aCold")) {
            val thr = s.int("coldC").toDouble()
            val h = next.minByOrNull { it.temp }
            if (h != null && h.temp <= thr) {
                out.add(
                    Alert(
                        "cold-" + h.time.substring(0, 10), AlertType.COLD, "Aşırı soğuk / don",
                        "${s.fmtTemp(h.temp)} · ${h.time.substring(11, 16)} civarı",
                        if (h.temp <= thr - 10) 3 else 2,
                    )
                )
            }
        }
        if (s.bool("aStorm")) {
            val h = next.firstOrNull { it.code in 95..99 }
            if (h != null) {
                out.add(
                    Alert(
                        "storm-" + h.time.substring(0, 10), AlertType.STORM, "Gök gürültülü fırtına",
                        "${h.time.substring(11, 16)} civarı bekleniyor",
                        if (h.code >= 96) 3 else 2,
                    )
                )
            }
        }
        if (s.bool("aSnow")) {
            val h = next.firstOrNull { it.code == 75 || it.code == 86 }
            if (h != null) {
                out.add(
                    Alert(
                        "snow-" + h.time.substring(0, 10), AlertType.SNOW, "Yoğun kar bekleniyor",
                        "${h.time.substring(11, 16)} civarı", 2,
                    )
                )
            }
        }
    }

    if (kp != null && s.bool("aGeo")) {
        val now = System.currentTimeMillis()
        val cur = kp.lastOrNull { it.timeMs <= now }
        val soon = kp.filter { it.timeMs > now && it.timeMs <= now + 24 * 3_600_000L }
        val peak = (listOfNotNull(cur) + soon).maxByOrNull { it.kp }
        val thr = s.int("geoKp")
        if (peak != null && peak.kp >= thr) {
            val g = gScale(peak.kp)
            val whenText = if (peak.timeMs <= now) "şu an" else fmtLocal(peak.timeMs, "dd.MM HH:mm")
            out.add(
                Alert(
                    "geo-" + fmtLocal(peak.timeMs, "yyyyMMdd") + "-" + g,
                    AlertType.GEO,
                    if (g > 0) "Manyetik fırtına: G$g" else "Manyetik aktivite yüksek",
                    "Kp ${fmt1(peak.kp)} ($whenText) · ${kpLabel(peak.kp)}",
                    if (g >= 3) 3 else 2,
                )
            )
        }
    }

    if (aqi != null && s.bool("aAqi") && aqi.european >= s.int("aqiMax")) {
        out.add(
            Alert(
                "aqi-" + fmtLocal(System.currentTimeMillis(), "yyyyMMdd"),
                AlertType.AQI, "Hava kalitesi kötü",
                "Avrupa hava kalitesi indeksi ${aqi.european} (${aqiLabel(aqi.european)}) · PM2.5 ${aqi.pm25.roundToInt()}",
                if (aqi.european >= 100) 3 else 2,
            )
        )
    }

    if (quakes != null && s.bool("aQuake")) {
        for (q in quakes) {
            val severe = q.mag >= 5.5 || (q.mag >= 4.5 && q.distKm < 100)
            out.add(
                Alert(
                    "quake-" + q.id, AlertType.QUAKE, "Deprem M${fmt1(q.mag)}",
                    "${q.place} · ${q.distKm.roundToInt()} km uzakta · ${fmtLocal(q.timeMs, "HH:mm")}",
                    if (severe) 3 else 2,
                )
            )
        }
    }

    return out.sortedByDescending { it.level }
}

/** Alarm sesi: önce sistemin alarm zil sesi, yoksa bildirim sesi, o da yoksa bip. */
object AlarmPlayer {
    private var ringtone: Ringtone? = null
    private var tone: ToneGenerator? = null

    fun start(ctx: Context) {
        stop()
        try {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            val r = RingtoneManager.getRingtone(ctx, uri)
            if (r != null) {
                r.audioAttributes = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
                r.play()
                ringtone = r
                return
            }
        } catch (e: Exception) {
            // bip'e düş
        }
        try {
            val t = ToneGenerator(AudioManager.STREAM_ALARM, 100)
            t.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 4000)
            tone = t
        } catch (e: Exception) {
            // ses çalınamadı
        }
    }

    fun stop() {
        try {
            ringtone?.stop()
        } catch (e: Exception) {
        }
        ringtone = null
        try {
            tone?.release()
        } catch (e: Exception) {
        }
        tone = null
    }
}
