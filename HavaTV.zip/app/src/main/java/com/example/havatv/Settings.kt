package com.example.havatv

import android.content.SharedPreferences
import androidx.compose.runtime.mutableStateMapOf

/** Tüm ayarların varsayılan değerleri. Yönetici konsolu bu anahtarları değiştirir. */
object Def {
    val values: Map<String, Any> = mapOf(
        // Konum
        "cityName" to "Yenimahalle (Ankara)",
        "cityLat" to 39.9667,
        "cityLon" to 32.8,
        // Birimler
        "tempUnit" to "C",
        "windUnit" to "kmh",
        "pressUnit" to "hpa",
        // Görünüm
        "uiScale" to 100,
        "liveBg" to true,
        "keepOn" to false,
        "rainSound" to true,
        "rainVol" to 60,
        // Tahmin
        "forecastDays" to 7,
        "hourStep" to 3,
        "hourCount" to 8,
        "refreshMin" to 15,
        // Veri kaynağı ağırlıkları (0 = kapalı). Eşit ağırlık = düz ortalama.
        "wOm" to 100,
        "wMet" to 100,
        "wMetar" to 100,
        "tSources" to true,
        // Hava ekranında gösterilecekler
        "tNowcast" to true,
        "tFeels" to true,
        "tHumidity" to true,
        "tWind" to true,
        "tPressure" to true,
        "tUv" to true,
        "tAqi" to true,
        "tSun" to true,
        "tMoon" to true,
        "tKp" to true,
        // Radar
        "radarLayer" to "radar",
        "radarBase" to "dark",
        "radarColor" to 2,
        "radarOpacity" to 75,
        "radarSpeed" to 500,
        "radarZoom" to 6,
        "radarSmooth" to true,
        "radarSnow" to true,
        // Alarmlar
        "alertsOn" to true,
        "alertSound" to true,
        "alertCheckMin" to 5,
        "aQuake" to true,
        "qSource" to "afad",
        "qMinMag" to 30,
        "qRadius" to 300,
        "qHours" to 3,
        "aWind" to true,
        "wGust" to 70,
        "aRain" to true,
        "rMm" to 15,
        "aHeat" to true,
        "heatC" to 38,
        "aCold" to true,
        "coldC" to -10,
        "aStorm" to true,
        "aSnow" to true,
        "aGeo" to true,
        "geoKp" to 5,
        "aAqi" to true,
        "aqiMax" to 80,
        // İç kullanım: daha önce çalan alarmların kimlikleri
        "seen" to "",
    )
}

/**
 * Ayar deposu. Değerler Compose durumu olarak tutulur, yani bir ayar değişince
 * onu okuyan ekranlar kendiliğinden yenilenir. Her değişiklik SharedPreferences'a yazılır.
 */
class Settings(private val prefs: SharedPreferences) {
    private val map = mutableStateMapOf<String, String>()

    init {
        for ((k, v) in prefs.all) {
            if (v != null) map[k] = v.toString()
        }
    }

    private fun raw(k: String): String = map[k] ?: Def.values[k]?.toString() ?: ""

    fun str(k: String): String = raw(k)
    fun bool(k: String): Boolean = raw(k) == "true"
    fun int(k: String): Int = raw(k).toIntOrNull() ?: 0
    fun dbl(k: String): Double = raw(k).toDoubleOrNull() ?: 0.0

    fun set(k: String, v: Any) {
        val s = v.toString()
        map[k] = s
        prefs.edit().putString(k, s).apply()
    }

    /** Konum dışındaki her şeyi varsayılana döndürür. */
    fun reset() {
        val keep = setOf("cityName", "cityLat", "cityLon")
        val remove = map.keys.filter { it !in keep }
        val e = prefs.edit()
        for (k in remove) {
            map.remove(k)
            e.remove(k)
        }
        e.apply()
    }

    fun seen(): List<String> = str("seen").split("|").filter { it.isNotEmpty() }

    fun markSeen(ids: List<String>) {
        val all = (seen() + ids).distinct().takeLast(300)
        set("seen", all.joinToString("|"))
    }
}
